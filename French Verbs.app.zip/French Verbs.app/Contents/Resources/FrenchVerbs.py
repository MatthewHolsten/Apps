###################################
###############################
#
#French Verbs Quiz Application
#By Matt Holsten
#
####################################
####################################
#native modules
from tkinter import *
from tkinter import ttk
from tkinter.colorchooser import askcolor
from tkinter import messagebox
import smtplib

#non native modules: PIL
from PIL import Image, ImageTk


class FrenchVerbsGUI:
	
	def __init__(self,root):
		print('__init__ func')
		self.root = root
		self.init_gui()
		self.vbs_counter = 0
	
	def init_gui(self):
		print('init gui func')
		self.root.title('French Verbs')
	
		#geometry specs
		width = 856
		height = 770
		x_shift = 295
		y_shift = 0
		self.window_geometry = '{}x{}+{}+{}'.format(width, height, x_shift, y_shift)
#		self.window_geometry = '856x795+295+0'
		

		self.default_color = '#6b97ff'
		self.init_verbs()
		self.init_menubar()
		self.starting_screen()
		self.isboot = True
		self.ISPRACTICE = True
		self.exited_test = False
		
	def starting_screen(self):
		try:
			self.root_color = self.new_color
		except:
			self.root_color = self.default_color
		try:
			self.load1 = Image.open("photo7.jpg")
			self.render1 = ImageTk.PhotoImage(self.load1)

			self.img1 = Label(root, image=self.render1)
			self.img1.image = self.render1

			self.img1.place(relx=0,rely=0,relwidth=1, relheight=1)
			self.root_color = 'white'
				
			
		except:
			
			self.root['bg'] = self.root_color
			self.main_label = Label(self.root, text='French II Verb Conjugations')
			self.main_label.config(font=("Courier italic", 45))
			self.main_label.place(relx=0.5, rely=0.47, anchor=CENTER)
			self.main_label['bg'] = self.root_color
			self.main_my_name = Label(self.root, text='Matt Holsten, STA \'19')
			self.main_my_name.config(font=("Courier", 15))
			self.main_my_name.place(relx=.15, rely=.02, anchor=CENTER)
			self.main_my_name['bg'] = self.root_color
			self.main_start_btn = Button(self.root, text='Start', width = 20, highlightbackground=self.root_color)
			self.main_start_btn.place(relx=.5, rely=.55, anchor=CENTER)
			self.main_start_btn.bind('<Button-1>', self.init_instructions_window)
			
		self.root.bind('<Return>', self.init_instructions_window)
		self.root.geometry(self.window_geometry)
	
	def init_menubar(self):
		print('init menubar func')
		menubar = Menu(self.root)
		self.root.config(menu=menubar)
		
		#file
		menu_file = Menu(menubar)
		menubar.add_cascade(label="File", menu=menu_file)
		menu_file.add_command(label="Exit\t\t\t\t\t\t⌘Q", command=self.client_quit_menu)
		menu_file.add_command(label="Restart\t\t\t\t\t⌘R", command=self.restart_menu) #FIX THIS
		menu_file.add_command(label='Restore Window\t\t\t⌘W', command=self.restore_window_menu)
		menu_file.add_command(label='Search\t\t\t\t\t⌘F', command=self.focus_search_bar_menu)
		menu_file.add_command(label="Verb List\t\t\t\t⌘L", command=self.verb_list_menu)
		menu_file.add_command(label='Special Characters\t\t⌘J', command=self.special_char_window_menu)
		
		
		#Help
		menu_info = Menu(menubar)
		menubar.add_cascade(label="Help ", menu=menu_info)
		menu_info.add_command(label="Instructions\t\t\t\t⌘I", command=self.init_instructions_window_menu)
		menu_info.add_command(label="Report a Problem\t\t⌘⇧B", command=self.bug_fix)
		

		#Info
		menu_info = Menu(menubar)
		menubar.add_cascade(label="Color", menu=menu_info)
		menu_info.add_command(label="Change Color\t\t⌘⇧C", command=self.change_color)
	
		self.root.bind('<Command-q>', self.client_quit_command)
		self.root.bind('<Command-r>', self.restart_command)
		self.root.bind('<Command-w>', self.restore_window_command)
		self.root.bind('<Command-j>', self.special_char_window_command)
		self.root.bind('<Command-i>', self.init_instructions_window_menu)
		self.root.bind('<Command-f>', self.focus_search_bar)
		self.root.bind('<Command-l>', self.verb_list_command)
		self.root.bind('<Command-C>', self.change_color_command)
		self.root.bind('<Command-B>', self.bug_fix_command)
		self.root.bind('<Left>', self.back_btn_func)
		self.root.bind('<Right>', self.next_btn_func)
		self.root.unbind('<Return>')
	
	def show_info_window(self, *event):
		print('show info')

	def toggle_boot_verbs(self):
		if self.isboot:
			self.isboot = False
		else:
			self.isboot = True
		print(self.isboot)
		try:
			self.quiz(self.vb)
		except:
			pass
	def toggle_boot_verbs_command(self, event):
		self.toggle_boot_verbs()
		
	def bug_fix(self):
		self.init_bug_fix_window()

	def bug_fix_command(self, event):
		self.bug_fix()
		
	def init_bug_fix_window(self):
		try:
			self.bug_fix_window.lift()

		except:
			r = 0
			c = 1
			try:
				self.bug_color = self.new_color
			except:
				self.bug_color = self.default_color
			
			self.bug_fix_window = Toplevel(self.root)
			self.bug_fix_window.resizable(False,False)
			self.bug_fix_window['bg'] = self.bug_color
			self.bug_fix_window.geometry('411x319')
			self.bug_fix_window.title('Problem Report')
			self.blnklbl1 = Label(self.bug_fix_window, width=2, height=3, bg=self.bug_color)
			self.blnklbl1.grid(row=0,column=0)
			

			self.bug_fix_title = Label(self.bug_fix_window, text='Problem Report Form')
			self.bug_fix_title['bg'] = self.bug_color
			self.bug_fix_title.config(font=('Arial bold', 18))
			self.bug_fix_title.place(relx=.262, rely=.025)
			
			self.short_desc_lbl = Label(self.bug_fix_window, text='Part of App')
			self.short_desc_lbl.grid(row=r+1,column=c, sticky='W')
			self.short_desc_lbl.config(font=('arial bold',15))
			self.short_desc_lbl['bg'] = self.bug_color
			self.short_desc_txt = Text(self.bug_fix_window, highlightbackground='black', highlightthickness=1, width=45, height=1)
			self.short_desc_txt.config(font=('courior',13))
			self.short_desc_txt.grid(row=r+2,column=c, sticky='W')
			self.short_desc_txt.focus()
			self.blnklbl2 = Label(self.bug_fix_window, bg=self.bug_color)
			self.blnklbl2.grid(row=r+3)

			self.long_desc_lbl = Label(self.bug_fix_window, text='Description')
			self.long_desc_lbl.grid(row=r+4,column=c, sticky='W')
			self.long_desc_lbl.config(font=('arial bold',15))
			self.long_desc_lbl['bg'] = self.bug_color


			self.long_desc_txt = Text(self.bug_fix_window, height=5, width=45, highlightbackground='black', highlightthickness=1)
			self.long_desc_txt.grid(row=r+5,column=c, sticky='W')
			self.long_desc_txt.config(font=('courior',13))

			self.blnklbl3 = Label(self.bug_fix_window, bg=self.bug_color)
			self.blnklbl3.grid(row=r+6)

			
			self.usr_email_lbl = Label(self.bug_fix_window, text='Email (optional, I\'ll respond if fixed)')
			self.usr_email_lbl.grid(row=r+7,column=c, sticky='W')
			self.usr_email_lbl.config(font=('arial bold',15))
			self.usr_email_lbl['bg'] = self.bug_color

			self.usr_email_txt = Text(self.bug_fix_window, width=35, height=1, highlightbackground='black', highlightthickness=1)
			self.usr_email_txt.grid(row=r+8,column=c, sticky='W')
			self.usr_email_txt.config(font=('courior',13))

			
			self.report_bug_btn = Button(self.bug_fix_window, text='Submit', command=self.bug_fix_submit, highlightbackground=self.bug_color)
			self.report_bug_btn.place(relx=.776, rely=.835)
		
	def bug_fix_submit(self):
		print('start to send email')
		
		if len(self.short_desc_txt.get('1.0', END)) > 1 and len(self.long_desc_txt.get('1.0', END)) > 1:	
			try:	
				user = 'BugReporter2000@gmail.com'
				recipients = 'tkinterapp@gmail.com'
				cc = ''
				bcc = ''
				subject = 'BUG REPORT FrenchVerbs, \'{}\''.format(self.short_desc_txt.get('1.0',END))
				message = 'App:\n{}\n\nArea of App:\n{}\n\nDescription:\n{}\n\nUser Email:\n{}'.format('FrenchVerbs',self.short_desc_txt.get('1.0', END), self.long_desc_txt.get('1.0', END), self.usr_email_txt.get('1.0', END))
				
				formatted_message = 'From: {0}\nTo: {1}\nCC: {2}\nBCC: {3}\nSubject: {4}\n{5}'.format(user, recipients, cc, bcc, subject, message)
				
				password = 'sneakysnake666'
				server = smtplib.SMTP('smtp.gmail.com', 587)
				server.ehlo()
				server.starttls()
				server.login(user, password)
				server.sendmail(user, recipients, formatted_message)
				server.close()
				self.issuccess = '  Thank You!'
				self.issmallfont = False
			except Exception as e:
				self.issuccess = e
				self.issmallfont = True
			
			for child in self.bug_fix_window.winfo_children():
				child.destroy()
			self.ty_lbl = Label(self.bug_fix_window, text=self.issuccess, bg=self.bug_color)
			if not self.issmallfont:
				self.ty_lbl.config(font=('Courior bold',40))
			if self.issmallfont:
				self.ty_lbl.config(font=('Courior bold',20))
			self.ty_lbl.place(relx=.2,rely=.4)
			
		if  len(self.short_desc_txt.get('1.0', END)) <= 1:
			self.short_desc_lbl['bg'] = 'white'
			self.short_desc_lbl['fg'] = 'red'			
			
		if len(self.long_desc_txt.get('1.0', END)) <=1:
			self.long_desc_lbl['bg'] = 'white'
			self.long_desc_lbl['fg'] = 'red'

	
	def albl_delete(self):
		self.albl.destroy()
	def blbl_delete(self):
		self.albl.destroy()
	
	def change_color(self):
		print('trying to change color') 
		
		user_picked_color = askcolor()[1]
		
		if user_picked_color != None:
			self.new_color = user_picked_color #hex code part
			try:
				if self.SUB:
					try:	
						self.btm_frame['bg'] = self.new_color
						self.check_bx_frame['bg'] = self.new_color
						for child in self.btm_frame.winfo_children():
							child['bg'] = self.new_color
							child['highlightbackground'] = self.new_color
						for child in self.check_bx_frame.winfo_children():
							child['bg'] = self.new_color
							child['highlightbackground'] = self.new_color
					except:
						pass
			except:
				pass
			try:
				self.done_btn['bg'] = self.new_color
			except:
				pass
			try:
				self.boot_lbl['bg'] = self.new_color
			except Exception as e:
				print(e)
			try:
				self.root['bg'] = self.new_color
			except:
				pass
			try:
				self.top_frame['bg'] = self.new_color
			except:
				pass
			try:
				self.main_start_btn['highlightbackground'] = self.new_color
				self.main_label['bg'] = self.new_color
				self.main_my_name['bg'] = self.new_color
			except:
				pass
			try:
				
				for child in self.top_frame.winfo_children():
					child['bg'] = self.new_color
					child['highlightbackground'] = self.new_color

				self.search_entry_label['bg'] = self.new_color
				self.search_entry['highlightbackground'] = self.new_color
			except:
				pass
			try:
				self.ty_lbl['bg'] = self.new_color
			except:
				pass
			try:
				self.sw_top['bg'] = self.new_color
				self.sw_bot['bg'] = self.new_color
				for child in self.sw_top.winfo_children():
					child['bg'] = self.new_color
				for child in self.sw_bot.winfo_children():
					child['bg'] = self.new_color
			except:
				pass
			try:
				self.bug_fix_window['bg'] = self.new_color
				self.bug_fix_title['bg'] = self.new_color
				self.short_desc_lbl['bg'] = self.new_color
				self.long_desc_lbl['bg'] = self.new_color
				self.usr_email_lbl['bg'] = self.new_color
				self.blnklbl1['bg'] = self.new_color
				self.blnklbl2['bg'] = self.new_color
				self.blnklbl3['bg'] = self.new_color
				self.report_bug_btn['highlightbackground'] = self.new_color
			except:
				pass
			try:
				self.boot_lbl['bg'] = self.new_color
			except:
				pass

	def change_color_command(self, event):
		self.change_color()
	#menu func
	def main_info_func(self, event):
			pass
			
	def client_quit_menu(self):
		print('client quit func')
		quit()
	def client_quit_command(self, event):
		self.client_quit_menu()
	#restart
	def restart_menu(self):

		for child in self.root.winfo_children():
			child.destroy()
		self.init_verbs()
		self.init_menubar()
		self.vbs_counter = 0
		self.starting_screen()
	def restart_command(self, event):
		self.restart_menu()
	#restore
	def restore_window_menu(self):
		print('restore window func')
		self.root.geometry(self.window_geometry)
	
	def restore_window_command(self, event):
		self.restore_window_menu()							
	
	def init_quiz(self):

		print('init quiz func')
		self.destroyer()
		self.init_containers()
		print(len(self.vbs))
		self.vbs_counter = (self.vbs_counter%len(self.vbs))
		print(self.vbs_counter) #Remove this line

		vb = self.vbs[self.vbs_counter]
		self.quiz(vb)
		self.vbs_counter+=1
		
	def write_to_instructions_file(self, *event):
		print('write_to_instructions_file')
		print('Opened \''+self.instructions_file_name+'\'')
		instructions_file = open(self.instructions_file_name, 'w')
		write_in = str(self.instructions_checkbox_var.get())
		instructions_file.write(write_in)
		print('Wrote: \''+write_in+'\'')
		instructions_file.close()
		print('Closed \''+self.instructions_file_name+'\'')
		self.init_quiz_btn_func()
		
	def init_instructions_window(self, *event):
		self.destroyer()
		self.root.bind('<Return>', self.write_to_instructions_file)
		print('init_instructions_window')
		self.instructions_file_name = 'fvinfobinary.txt'
		try:
			instructions_file = open(self.instructions_file_name, 'r')
			print('Opened \''+self.instructions_file_name+'\'')
			instructions_file_info = instructions_file.read()
			print('Contents: \''+instructions_file_info+'\'')
			try:
				self.instructions_cb_var.set(int(instructions_file_info))
			except:
				pass
		except:	
			instructions_file = open(self.instructions_file_name, 'w+')
			instructions_file_info = instructions_file.read()
			
		instructions_file.close()
		print('Closed \''+self.instructions_file_name+'\'')
		
		#if file info = 1 or user clicked from menubar
		try:
			clicked_information = self.clicked_information
		except:
			clicked_information = False
		if instructions_file_info == '1' and not clicked_information:
			self.init_quiz_btn_func()
		else:
			#import image with instructions
			try:
				self.load2 = Image.open("info5.jpg")
				self.render2 = ImageTk.PhotoImage(self.load2)

				self.img2 = Label(root, image=self.render2)
				self.img2.image = self.render2

				self.img2.place(relx=0,rely=0,relwidth=1, relheight=1)
				self.root_color = 'white'
			except:
				Label(self.root, text='Image Import Error. Report Error 104.').grid()

			#or textbox with no boarder and uneditable
			self.instructions_checkbox_var =IntVar()
			check_box = Checkbutton(self.root, text='Do not show again.',\
			 variable=self.instructions_checkbox_var, bg='white', fg='blue')
			check_box.place(relx=.41, rely=.6) #grid  this
			
			#set the checkbox to selected/not selected
			if instructions_file_info != '':
				self.instructions_checkbox_var.set(int(instructions_file_info))
			
			start_btn = Button(self.root, text='Continue',\
			 command=self.write_to_instructions_file, highlightbackground='white', fg='blue')
			start_btn.place(relx=.45, rely=.63) #grid this

		
	def init_instructions_window_menu(self, *event):
		print('init_instructions_window_menu')
		self.clicked_information = True
		self.init_instructions_window()
		
	def init_quiz_btn_func(self, *event):
		print('start btn')
		
#		self.init_containers()
		self.init_quiz()
	
	def init_containers(self):
		self.root['bg']='white'
		#EE8E8E
		try:
			self.top_frame_color = self.new_color
		except:
			self.top_frame_color = self.default_color	
		self.top_frame = Frame(self.root, bg=self.top_frame_color)
		self.top_frame.grid(row=0, column=0, sticky="ew")
#		self.top_frame.config(height=25)

		self.center_color = 'white'
		self.center = Frame(self.root, bg=self.center_color)
		self.center.grid(row=1, column=0, sticky="nsew")
		
#		self.btm_frame_color = 'blue'
		self.btm_frame_color = 'white'
		self.btm_frame = Frame(self.root, bg=self.btm_frame_color, height=25)
		self.btm_frame.grid(row = 2, column=0, sticky="nsew")
		self.btm_frame_t = Frame(self.btm_frame, bg=self.btm_frame_color)
		self.btm_frame_t.place(relx=.09, rely=.15)
			
				
		self.root.grid_rowconfigure(1, weight=1)
		self.root.grid_columnconfigure(0, weight=1)

		self.search_frame = Frame(self.top_frame, bg=self.top_frame_color)
		self.search_frame.place(relx=.971, rely=.48, anchor=NE)
#		self.search_frame.grid(row=0, column=3, sticky='nsew')
		
		
		self.check_bx_frame = Frame(self.btm_frame, bg=self.btm_frame_color)
		self.check_bx_frame.place(relx=1,rely=.86, anchor=SE)
#		self.check_bx_frame.grid(row=0, column=2, sticky=E)z	#func to call for start btn
	

	#search func
	def quiz_search(self, event):
		if self.search_entry.get() == '':
			print('search blank')
		else:
			print('search', self.search_entry.get())
			self.each_vb = None
			for each_vb in self.vbs:
				if each_vb['name'] == self.search_entry.get().lower() or each_vb['defn'] == self.search_entry.get().lower():
					self.each_vb = each_vb
					break
			if self.each_vb != None:
				self.vbs_counter = self.vbs.index(self.each_vb)
				self.init_quiz()
			else:
				try:
					self.no_name_lbl.destroy()
				except:
					pass
				try:
					nnl_bg = self.new_color
				except:
					nnl_bg = self.default_color
				self.no_name_lbl = Label(self.search_frame, text=u'\u274C', bg=nnl_bg)
				self.no_name_lbl.grid(row=0, column=0)
				self.no_name_lbl.after(750, lambda: self.no_name_lbl.destroy())
			

	def focus_search_bar(self, event):
		self.focus_search_bar_menu()

	def focus_search_bar_menu(self):
		print('focus search bar')
		self.search_entry.focus()
		
	def verb_list_menu(self):
		try:
			self.verb_list_window.lift()
			#checking if window already open
		except:
			print('verb list window init')
			self.verb_list_window = Toplevel(self.root)
			self.verb_list_window.title('Verb List')
			
			i, j = 0, -1
			n = 0
			for verb in self.vbs:
				n +=1
				j +=1
				if j%10 == 0:
					i +=1
					j = 0
				lbl = Label(self.verb_list_window, text='-{}'.format(verb['name'].title()))
				lbl.config(font=('Arial ', 20))
				lbl.grid(row=j, column=i, padx= 5, pady=10, sticky=W)
	
	def verb_list_command(self, event):
			self.verb_list_menu()

	def special_char_window_menu(self):
		try:
			self.special_char_window.destroy()
		except:
			pass
			
		print('sepcial char window init')
		self.special_char_window = Toplevel(self.root)
		self.special_char_window.title('Special Characters')
		char_list = 'éèêëáàâäæçïîôœùûüÿ'
		i, j = 0, -1
		for char in char_list:
			j +=1
			if j%3 == 0:
				i +=1
				j = 0
			txt = Text(self.special_char_window, height=1,  width=5, borderwidth=0)
			txt.insert(1.0, char)
			txt.config(font=('Arial', 20))
			txt.grid(row=i, column=j)
	
	def special_char_window_command(self, event):
		self.special_char_window_menu()
	
	def save_test_answers(self):
		if not self.ISPRACTICE:
			print('save answers')
			self.answer_entry_dict = [
									(self.pres_je_entry, self.vb['pres_je'], 'pres_je'), 
									(self.pres_tu_entry, self.vb['pres_tu'], 'pres_tu'), 
									(self.pres_il_entry, self.vb['pres_il'], 'pres_il'), 
									(self.pres_n_entry, self.vb['pres_n'], 'pres_n'), 
									(self.pres_v_entry, self.vb['pres_v'], 'pres_v'), 
									(self.pres_ils_entry, self.vb['pres_ils'], 'pres_ils'), 
									(self.imp_je_entry, self.vb['imp_je'], 'imp_je'), 
									(self.imp_tu_entry, self.vb['imp_tu'], 'imp_tu'), 
									(self.imp_il_entry, self.vb['imp_il'], 'imp_il'), 
									(self.imp_n_entry, self.vb['imp_n'], 'imp_n'), 
									(self.imp_v_entry, self.vb['imp_v'], 'imp_v'), 
									(self.imp_ils_entry, self.vb['imp_ils'], 'imp_ils'), 
									(self.fut_je_entry, self.vb['fut_je'], 'fut_je'), 
									(self.fut_tu_entry, self.vb['fut_tu'], 'fut_tu'), 
									(self.fut_il_entry, self.vb['fut_il'], 'fut_il'), 
									(self.fut_n_entry, self.vb['fut_n'], 'fut_n'), 
									(self.fut_v_entry, self.vb['fut_v'], 'fut_v'), 
									(self.fut_ils_entry, self.vb['fut_ils'], 'fut_ils'), 
									(self.cond_je_entry, self.vb['cond_je'], 'cond_je'), 
									(self.cond_tu_entry, self.vb['cond_tu'], 'cond_tu'), 
									(self.cond_il_entry, self.vb['cond_il'], 'cond_il'), 
									(self.cond_n_entry,self.vb['cond_n'], 'cond_n'), 
									(self.cond_v_entry, self.vb['cond_v'], 'cond_v'), 
									(self.cond_ils_entry, self.vb['cond_ils'], 'cond_ils'), 
									(self.subj_je_entry, self.vb['subj_je'], 'subj_je'), 
									(self.subj_tu_entry, self.vb['subj_tu'], 'subj_tu'), 
									(self.subj_il_entry, self.vb['subj_il'], 'subj_il'), 
									(self.subj_n_entry, self.vb['subj_n'], 'subj_n'), 
									(self.subj_v_entry, self.vb['subj_v'], 'subj_v'), 
									(self.subj_ils_entry, self.vb['subj_ils'], 'subj_ils'), 
									(self.imper_tu_entry, self.vb['imper_tu'], 'imper_tu'),  
									(self.imper_n_entry, self.vb['imper_n'], 'imper_n'), 
									(self.imper_v_entry, self.vb['imper_v'], 'imper_v'), 
									(self.pc_entry, self.vb['pc'], 'pc')
									]
			
			for i in self.answer_entry_dict:
				user_ans = i[0].get()
				correct_ans = i[1]
				ans_type = i[2]
				vb_name = self.vb['name']
				
				if user_ans != '': 
					if user_ans == correct_ans:
						self.correct_counter +=1
					else:
						self.incorrect_counter +=1
						self.test_incorrect_list.append((vb_name, ans_type, correct_ans, user_ans))
					

	def next_btn_func(self, event):
		print('next btn')
		self.save_test_answers()
		self.init_quiz()

	def back_btn_func(self, event):
		print('back btn')
		self.vbs_counter -= 2
		self.init_quiz()
	
	def boot_enter(self, event):
		print('enter')
		self.boot_desc_lbl = Label(self.top_frame, text='* :  Boot Verb', pady=5, padx=10)
		self.boot_desc_lbl.config(font=('Arial bold italic', 12))
		self.boot_desc_lbl.grid(row=1,column=3, sticky='sw')
#		self.boot_desc_lbl.grid(row=0,column=2, sticky='s')

		
		try:
			self.boot_desc_lbl['bg'] = self.new_color
		except:
			self.boot_desc_lbl['bg'] = self.default_color
		
	def boot_leave(self, event):
		print('leave')
		try:
			self.boot_desc_lbl.destroy()
		except Exception as e:
			print(e)
	
	def toggle_test_practice(self, tog=[0]):
			self.SUB = False
			print(tog[0])
			if tog[0]:
				
				##################  PRACTICE MODE  #######################
				
				if self.exited_test:
					try:
						self.practice_btn.destroy()
					except:
						pass
					try:
						self.test_lbl.destroy()
					except:
						pass
					print('practice mode activated')
					tog[0] = not tog[0]
					self.toggle_boot_verbs()
					self.ISPRACTICE = True
					self.exited_test = False
					self.vbs_counter = 0
					self.init_quiz()
					
				elif messagebox.askokcancel('','Warning: If you wish to enter Practice Mode, your progress on this test session will be lost.'):
					try:
						self.practice_btn.destroy()
					except:
						pass
					try:
						self.test_lbl.destroy()
					except:
						pass
					print('practice mode activated')
					tog[0] = not tog[0]
					self.toggle_boot_verbs()
					self.ISPRACTICE = True
					self.exited_test = False
					self.vbs_counter = 0
					self.init_quiz()
				#########################################
				try:
					self.btm_frame['bg'] = 'white'
				except:
					pass
				try:
					self.root.bind('<Return>',self.quiz_search)
				except:
					pass
				try:
					self.top_frame_color = self.new_color
					for child in self.top_frame.winfo_children():
						child['bg'] = self.top_frame_color
				except Exception as e:
					print(e)	
			else:
				###################  TEST MODE  ######################
				if messagebox.askyesno('','Enter Test Mode?'):
					try:
						self.root.unbind('<Return>')
					except:
						pass
					try:
						self.init_entries()
					except:
						pass
					try:
						try:
							for i in self.entries():
								ans = i[0]
								ans.destroy()
						except:
							pass
					except:
						pass
					try:
						self.practice_lbl.destroy()
					except:
						pass
					try:
						self.test_btn.destroy()
					except:
						pass
					print('test mode activated')
					
					tog[0] = not tog[0]
					self.ISPRACTICE = False
					self.correct_counter = 0
					self.incorrect_counter = 0
					self.toggle_boot_verbs()
					self.test_incorrect_list = []
				try:
					self.top_frame_color = self.new_color
					for child in self.top_frame.winfo_children():
						child['bg'] = self.top_frame_color
				except Exception as e:
					print(e)	
			self.quiz(self.vbs[0])
				#########################################
	def toggle_test_practice_event(self, event):
		self.toggle_test_practice()
		
	'''MAIN QUIZ FUNCTION'''
	def quiz(self, verb):
		print('quiz func')
		self.destroyer()
		if not self.ISPRACTICE:
			self.root.unbind('<Left>')
		else:
			self.root.bind('<Left>', self.back_btn_func)
		blank_lbl1 = Label(self.center, text='', width=1)
		blank_lbl1.grid(row=0, column=0)
#		blank_lbl1.propegate()
		blank_lbl2 = Label(self.center, text='', width=3).grid(row=0, column=4)
#		blank_lbl3 = Label(self.center, text='', width=1).grid(row=0, column=8)
	
		
		'''TOP FRAME WIDGETS'''
		self.vb = verb
		self.vbl_row, self.vbl_col = 0, 1
		
		blanklbl1 = Label(self.top_frame, text='', width=0)
		blanklbl1.grid(row = self.vbl_row, column = 1)
		blanklbl1['bg'] = self.top_frame_color

		blnklbl1 = Label(self.center, width=15, bg='white')
		blnklbl1.grid(row=0, column=3)
			
		#Verb Label
		try:
			self.vb_label.destroy()
		except:
			pass
		self.vb_label = Label(self.top_frame, text=self.vb['name'].capitalize(), bg=self.top_frame_color, anchor='w')
		self.vb_label.grid(row=self.vbl_row+1, column=self.vbl_col-1, padx= 10, sticky='e')
		self.vb_label.grid_propagate()
		self.vb_label.config(font=('Arial bold', 35))
		#Defn Label
		try:
			self.vb_defn_label.destroy()
		except:
			pass
		self.vb_defn_label = Label(self.top_frame, text='{}'.format(self.vb['defn']), bg=self.top_frame_color)
		self.vb_defn_label.grid(row=self.vbl_row+1, column=self.vbl_col+1, pady=3,padx=10, sticky='sw')
		self.vb_defn_label.grid_propagate()
		self.vb_defn_label.config(font=('Arial bold italic', 15))
		
		try:
			self.boot_lbl.destroy()
		except:
			pass
		
		if self.isboot:
			isboot_text = '*'
		else:
			isboot_text = ' '
		if self.vb['boot']:
			self.boot_lbl = Label(self.top_frame, text=isboot_text, borderwidth=0, width=0)
			self.boot_lbl.config(font=('Arial',30))
			try:
				self.boot_lbl['bg'] = self.new_color
			except:
				self.boot_lbl['bg'] = self.default_color
			self.boot_lbl.grid(row=self.vbl_row+1, column=self.vbl_col)
		try:
			if self.ISPRACTICE:
				self.boot_lbl.bind("<Enter>", self.boot_enter)
				self.boot_lbl.bind("<Leave>", self.boot_leave)
			else:
				try:
					self.boot_lbl.unbind("<Enter>")
					self.boot_lbl.unbind("<Leave>")
				except:
					pass
		except Exception as e:
			pass
		
		ent_width = 14 
		
		#Search Bar
			#entry
		try:
			self.test_btn.destroy()
		except:
			pass
		try:
			self.practice_btn.destroy()
		except:
			pass
		try:
			self.test_lbl.destroy()
		except:
			pass
		try:
			self.practice_lbl.destroy()
		except:
			pass
		try:
			self.mode_lbl.destroy()
		except:
			pass
			
		Label(self.btm_frame, width=2, height=2).grid(row=0, column=0)
#		self.mode_lbl = Label(self.check_bx_frame, text='Mode:', anchor='e', pady=2, padx=3)
#		self.mode_lbl.config(font=('Arial bold', 14))
#		self.mode_lbl.grid(row=0,column=1, sticky='se')

		if self.ISPRACTICE:
			try:
				self.practice_btn.destroy()
			except:
				pass
			try:
				self.test_lbl.destroy()
			except:
				pass
				
			
			self.practice_lbl = Label(self.btm_frame_t, text='Practice', width=7, relief='sunken', pady=2, bd=2)	
			self.practice_lbl.grid(row=0, column=2, sticky='se')
			self.practice_lbl.config(font=('arial bold', 13))	
#			self.test_btn = Button(self.btm_frame, text='Test', command=self.toggle_test_practice, highlightthickness = 0, bd = 0)
#			self.test_btn.grid(column=2,row=0, sticky='sw')
			self.test_btn = Label(self.btm_frame_t, text='Test', width=7, relief='raised', pady=2, bd=2)
#			Label(self.check_bx_frame, width=4).grid(column=4, row=0)
			self.test_btn.grid(column=3,row=0, sticky='sw')
			self.test_btn.bind('<Button-1>', self.toggle_test_practice_event)
			self.test_btn.config(font=('arial bold', 13))


		else:
			try:
				self.practice_lbl.destroy()
			except:
				pass
			try:
				self.test_btn.destroy()
			except:
				pass
				
#			self.practice_btn = Button(self.btm_frame, text='Practice', command=self.toggle_test_practice, width=5, highlightthickness = 0, bd = 0)	
#			self.practice_btn.grid(row=0, column=1, sticky='se')
			self.practice_btn = Label(self.btm_frame_t, text='Practice', width=7, relief='raised', pady=2, bd=2)	
			self.practice_btn.grid(row=0, column=1, sticky='se')
			self.practice_btn.bind('<Button-1>', self.toggle_test_practice_event)
			self.practice_btn.config(font=('arial bold', 13))	
			self.test_lbl = Label(self.btm_frame_t, text='Test', width=7, relief='sunken', pady=2, bd=2)
			self.test_lbl.grid(row=0, column=2, sticky='sw')	
			self.test_lbl.config(font=('arial bold', 13))	
			
		try:
			self.search_entry.destroy()
			self.search_entry_label.destroy()
		except:
			pass
		if self.ISPRACTICE:
			self.search_entry = Entry(self.search_frame, width=ent_width, highlightbackground=self.top_frame_color)
			self.search_entry.grid(row=0, column=2, sticky=NE)# padx=10, pady=10)
			self.root.bind('<Return>',self.quiz_search) #bind enter to search bar
				#label
			self.search_entry_label = Label(self.search_frame, text='Search:', bg=self.top_frame_color)
			self.search_entry_label.config(font=('Arial bold', 15))
			self.search_entry_label.grid(row=0, column=1, sticky=E)#, padx=10, pady=10)
		
		 #answers entry width
		self.quiz_labels = []
		''' PRESENT QUIZ '''
		self.pres_row, self.pres_col = self.vbl_row + 3, self.vbl_col #origin for present
		self.present_label = Label(self.center, text='Présent (indicatif)')
		self.present_label.grid(row=self.pres_row, column=self.pres_col+1, sticky=W)
		self.present_label.config(font=('Arial bold', 15))

		#JE		
		self.pres_je_label = Label(self.center, text='Je/J\':')
		self.pres_je_label.grid(row=self.pres_row+1,column=self.pres_col, sticky=E)		

		self.pres_je_entry = Entry(self.center)
		self.pres_je_entry.grid(row=self.pres_row+1,column=self.pres_col+1)		
		self.root.focus()
		self.pres_je_entry.focus()	
		#Tu
		self.pres_tu_label = Label(self.center, text='Tu:')
		self.pres_tu_label.grid(row=self.pres_row+2,column=self.pres_col, sticky=E)		

		self.pres_tu_entry = Entry(self.center)
		self.pres_tu_entry.grid(row=self.pres_row+2,column=self.pres_col+1)		
		
		#Il
		self.pres_il_label = Label(self.center, text='Il/Elle:')
		self.pres_il_label.grid(row=self.pres_row+3,column=self.pres_col, sticky=E)		

		self.pres_il_entry = Entry(self.center)
		self.pres_il_entry.grid(row=self.pres_row+3,column=self.pres_col+1)		


		#Nous
		self.pres_n_label = Label(self.center, text='Nous:')
		self.pres_n_label.grid(row=self.pres_row+4,column=self.pres_col, sticky=E)		

		self.pres_n_entry = Entry(self.center)
		self.pres_n_entry.grid(row=self.pres_row+4,column=self.pres_col+1)		
	
		#Vous
		self.pres_v_label = Label(self.center, text='Vous:')
		self.pres_v_label.grid(row=self.pres_row+5,column=self.pres_col, sticky=E)		

		self.pres_v_entry = Entry(self.center)
		self.pres_v_entry.grid(row=self.pres_row+5,column=self.pres_col+1)		
				
				
		#Ils
		self.pres_ils_label = Label(self.center, text='Ils/Elles:')
		self.pres_ils_label.grid(row=self.pres_row+6,column=self.pres_col, sticky=E)		

		self.pres_ils_entry = Entry(self.center)
		self.pres_ils_entry.grid(row=self.pres_row+6,column=self.pres_col+1)		
				
		
		blank_lblp1 = Label(self.center, text='').grid(row=self.pres_row+7, column=self.pres_col+2)
#		self.quiz_labels.append(self.present_label
#		 self.pres_je_label, self.pres_tu_label, self.pres_il_label, \
#		self.pres_n_label, self.pres_v_label, self.pres_v_label)
		
		
		'''IMPARFAIT QUIZ'''
		self.imp_row, self.imp_col = self.pres_row+8, self.pres_col

		self.imp_label = Label(self.center, text='Imparfait (indicatif)')
		self.imp_label.grid(row=self.imp_row, column=self.imp_col+1, sticky=W)
		self.imp_label.config(font=('Arial bold', 15))

		#JE		
		self.imp_je_label = Label(self.center, text='Je/J\'')
		self.imp_je_label.grid(row=self.imp_row+1,column=self.imp_col, stick=E)		
		
		self.imp_je_entry = Entry(self.center)
		self.imp_je_entry.grid(row=self.imp_row+1,column=self.imp_col+1)		
				
						
		#Tu
		self.imp_tu_label = Label(self.center, text='Tu:')
		self.imp_tu_label.grid(row=self.imp_row+2,column=self.imp_col, sticky=E)		

		self.imp_tu_entry = Entry(self.center)
		self.imp_tu_entry.grid(row=self.imp_row+2,column=self.imp_col+1)		
		
		
		#Il
		self.imp_il_label = Label(self.center, text='Il/Elle:')
		self.imp_il_label.grid(row=self.imp_row+3,column=self.imp_col, sticky=E)		

		self.imp_il_entry = Entry(self.center)
		self.imp_il_entry.grid(row=self.imp_row+3,column=self.imp_col+1)		
				

		#Nous
		self.imp_n_label = Label(self.center, text='Nous:')
		self.imp_n_label.grid(row=self.imp_row+4,column=self.imp_col, sticky=E)		
		
		self.imp_n_entry = Entry(self.center)
		self.imp_n_entry.grid(row=self.imp_row+4,column=self.imp_col+1)		
				
		
		#Vous
		self.imp_v_label = Label(self.center, text='Vous:')
		self.imp_v_label.grid(row=self.imp_row+5,column=self.imp_col, sticky=E)		

		self.imp_v_entry = Entry(self.center)
		self.imp_v_entry.grid(row=self.imp_row+5,column=self.imp_col+1)		
				
				#Ils
		self.imp_ils_label = Label(self.center, text='Ils/Elles:')
		self.imp_ils_label.grid(row=self.imp_row+6,column=self.imp_col, sticky=E)		

		self.imp_ils_entry = Entry(self.center)
		self.imp_ils_entry.grid(row=self.imp_row+6,column=self.imp_col+1)		
				
				
		blank_lblp1 = Label(self.center, text='').grid(row=self.imp_row+7, column=self.imp_col+2)

		'''SUBJUNCTIVE QUIZ'''
		self.subj_row, self.subj_col = self.imp_row+8, self.pres_col #origin

		self.subj_label = Label(self.center, text='Subjonctif (présent)')
		self.subj_label.grid(row=self.subj_row, column=self.subj_col+1, sticky=W)
		self.subj_label.config(font=('Arial bold', 15))

		#JE		
		self.subj_je_label = Label(self.center, text='Je/J\'')
		self.subj_je_label.grid(row=self.subj_row+1,column=self.subj_col, stick=E)		
		
		self.subj_je_entry = Entry(self.center)
		self.subj_je_entry.grid(row=self.subj_row+1,column=self.subj_col+1)		
				
				#Tu
		self.subj_tu_label = Label(self.center, text='Tu:')
		self.subj_tu_label.grid(row=self.subj_row+2,column=self.subj_col, sticky=E)		

		self.subj_tu_entry = Entry(self.center)
		self.subj_tu_entry.grid(row=self.subj_row+2,column=self.subj_col+1)		
		
				#Il
		self.subj_il_label = Label(self.center, text='Il/Elle:')
		self.subj_il_label.grid(row=self.subj_row+3,column=self.subj_col, sticky=E)		

		self.subj_il_entry = Entry(self.center)
		self.subj_il_entry.grid(row=self.subj_row+3,column=self.subj_col+1)		
				
		
		#Nous
		self.subj_n_label = Label(self.center, text='Nous:')
		self.subj_n_label.grid(row=self.subj_row+4,column=self.subj_col, sticky=E)		
		
		self.subj_n_entry = Entry(self.center)
		self.subj_n_entry.grid(row=self.subj_row+4,column=self.subj_col+1)		
				
				#Vous
		self.subj_v_label = Label(self.center, text='Vous:')
		self.subj_v_label.grid(row=self.subj_row+5,column=self.subj_col, sticky=E)		

		self.subj_v_entry = Entry(self.center)
		self.subj_v_entry.grid(row=self.subj_row+5,column=self.subj_col+1)		
				
		
		#Ils
		self.subj_ils_label = Label(self.center, text='Ils/Elles:')
		self.subj_ils_label.grid(row=self.subj_row+6,column=self.subj_col, sticky=E)		

		self.subj_ils_entry = Entry(self.center)
		self.subj_ils_entry.grid(row=self.subj_row+6,column=self.subj_col+1)		
				

		'''FUTURE QUIZ'''

		self.fut_row, self.fut_col = self.pres_row, self.pres_col+4 #origin

		self.fut_label = Label(self.center, text='Futur (indicatif)')
		self.fut_label.grid(row=self.fut_row, column=self.fut_col+1, sticky=W)
		self.fut_label.config(font=('Arial bold', 15))

		#JE		
		self.fut_je_label = Label(self.center, text='Je/J\'')
		self.fut_je_label.grid(row=self.fut_row+1,column=self.fut_col, stick=E)		
		self.fut_je_entry = Entry(self.center)
		self.fut_je_entry.grid(row=self.fut_row+1,column=self.fut_col+1)		
		
		#Tu
		self.fut_tu_label = Label(self.center, text='Tu:')
		self.fut_tu_label.grid(row=self.fut_row+2,column=self.fut_col, sticky=E)		
		self.fut_tu_entry = Entry(self.center)
		self.fut_tu_entry.grid(row=self.fut_row+2,column=self.fut_col+1)		
		
		#Il
		self.fut_il_label = Label(self.center, text='Il/Elle:')
		self.fut_il_label.grid(row=self.fut_row+3,column=self.fut_col, sticky=E)		
		self.fut_il_entry = Entry(self.center)
		self.fut_il_entry.grid(row=self.fut_row+3,column=self.fut_col+1)		
		
		#Nous
		self.fut_n_label = Label(self.center, text='Nous:')
		self.fut_n_label.grid(row=self.fut_row+4,column=self.fut_col, sticky=E)		
		
		self.fut_n_entry = Entry(self.center)
		self.fut_n_entry.grid(row=self.fut_row+4,column=self.fut_col+1)		
				
		
		#Vous
		self.fut_v_label = Label(self.center, text='Vous:')
		self.fut_v_label.grid(row=self.fut_row+5,column=self.fut_col, sticky=E)		

		self.fut_v_entry = Entry(self.center)
		self.fut_v_entry.grid(row=self.fut_row+5,column=self.fut_col+1)		
				
		
		#Ils
		self.fut_ils_label = Label(self.center, text='Ils/Elles:')
		self.fut_ils_label.grid(row=self.fut_row+6,column=self.fut_col, sticky=E)		

		self.fut_ils_entry = Entry(self.center)
		self.fut_ils_entry.grid(row=self.fut_row+6,column=self.fut_col+1)		
				
	
		'''CONDITIONAL QUIZ'''
		self.cond_row, self.cond_col = self.imp_row, self.fut_col #origin

		self.cond_label = Label(self.center, text='Conditionnel (présent)')
		self.cond_label.grid(row=self.cond_row, column=self.cond_col+1, sticky=W)
		self.cond_label.config(font=('Arial bold', 15))

		#JE		
		self.cond_je_label = Label(self.center, text='Je/J\'')
		self.cond_je_label.grid(row=self.cond_row+1,column=self.cond_col, stick=E)		
		
		self.cond_je_entry = Entry(self.center)
		self.cond_je_entry.grid(row=self.cond_row+1,column=self.cond_col+1)		
				
			
		#Tu
		self.cond_tu_label = Label(self.center, text='Tu:')
		self.cond_tu_label.grid(row=self.cond_row+2,column=self.cond_col, sticky=E)		

		self.cond_tu_entry = Entry(self.center)
		self.cond_tu_entry.grid(row=self.cond_row+2,column=self.cond_col+1)		
		
		
		#Il
		self.cond_il_label = Label(self.center, text='Il/Elle:')
		self.cond_il_label.grid(row=self.cond_row+3,column=self.cond_col, sticky=E)		

		self.cond_il_entry = Entry(self.center)
		self.cond_il_entry.grid(row=self.cond_row+3,column=self.cond_col+1)		
				
		
		#Nous
		self.cond_n_label = Label(self.center, text='Nous:')
		self.cond_n_label.grid(row=self.cond_row+4,column=self.cond_col, sticky=E)		
		
		self.cond_n_entry = Entry(self.center)
		self.cond_n_entry.grid(row=self.cond_row+4,column=self.cond_col+1)		
				
		
		#Vous
		self.cond_v_label = Label(self.center, text='Vous:')
		self.cond_v_label.grid(row=self.cond_row+5,column=self.cond_col, sticky=E)		

		self.cond_v_entry = Entry(self.center)
		self.cond_v_entry.grid(row=self.cond_row+5,column=self.cond_col+1)		
		
		#Ils
		self.cond_ils_label = Label(self.center, text='Ils/Elles:')
		self.cond_ils_label.grid(row=self.cond_row+6,column=self.cond_col, sticky=E)		

		self.cond_ils_entry = Entry(self.center)
		self.cond_ils_entry.grid(row=self.cond_row+6,column=self.cond_col+1)		
				
				
		'''IMPERITIVE QUIZ'''
		self.imper_row, self.imper_col = self.subj_row, self.cond_col #origin

		self.imper_label = Label(self.center, text='Impératif')
		self.imper_label.grid(row=self.imper_row, column=self.imper_col+1, sticky=W)
		self.imper_label.config(font=('Arial bold', 15))

		#Tu
		self.imper_tu_label = Label(self.center, text='Tu:')
		self.imper_tu_label.grid(row=self.imper_row+1,column=self.imper_col, sticky=E)		

		self.imper_tu_entry = Entry(self.center)
		self.imper_tu_entry.grid(row=self.imper_row+1,column=self.imper_col+1)		
		
				#Nous
		self.imper_n_label = Label(self.center, text='Nous:')
		self.imper_n_label.grid(row=self.imper_row+2,column=self.imper_col, sticky=E)		
		
		self.imper_n_entry = Entry(self.center)
		self.imper_n_entry.grid(row=self.imper_row+2,column=self.imper_col+1)		
				
				#Vous
		self.imper_v_label = Label(self.center, text='Vous:')
		self.imper_v_label.grid(row=self.imper_row+3,column=self.imper_col, sticky=E)		

		self.imper_v_entry = Entry(self.center)
		self.imper_v_entry.grid(row=self.imper_row+3,column=self.imper_col+1)		

		
		'''PASSE COMPOSE QUIZ'''
		
		self.pc_row, self.pc_col = self.imper_row+5, self.imper_col
		self.pc_label = Label(self.center, text='Passé Composé')
		self.pc_label.grid(row=self.pc_row, column=self.pc_col+1, sticky=W)
		self.pc_label.config(font=('Arial bold', 15))

		
		self.pc_pc_label = Label(self.center, text='Pc:')
		self.pc_pc_label.grid(row=self.pc_row+1,column=self.pc_col, sticky=E)		
	
		self.pc_entry = Entry(self.center)
		self.pc_entry.grid(row=self.pc_row+1,column=self.pc_col+1)		

		
		
		'''ANSWER ENTRIES FOR TABBING '''
					
		if self.ISPRACTICE:
			# pres
			self.pres_je_answer = Entry(self.center,width=ent_width)
			self.pres_je_answer.grid(row=self.pres_row+1, column = self.pres_col+2)
			self.pres_je_answer.config(stat='readonly')
			self.pres_tu_answer = Entry(self.center,width=ent_width)
			self.pres_tu_answer.grid(row=self.pres_row+2, column = self.pres_col+2, sticky=W+E)
			self.pres_tu_answer.config(stat='readonly')
			self.pres_il_answer = Entry(self.center,width=ent_width)
			self.pres_il_answer.grid(row=self.pres_row+3, column = self.pres_col+2, sticky=W+E)
			self.pres_il_answer.config(stat='readonly')
			self.pres_n_answer = Entry(self.center,width=ent_width)
			self.pres_n_answer.grid(row=self.pres_row+4, column = self.pres_col+2, sticky=W+E)
			self.pres_n_answer.config(stat='readonly')
			self.pres_v_answer = Entry(self.center,width=ent_width)
			self.pres_v_answer.grid(row=self.pres_row+5, column = self.pres_col+2, sticky=W+E)
			self.pres_v_answer.config(stat='readonly')
			self.pres_ils_answer = Entry(self.center,width=ent_width)
			self.pres_ils_answer.grid(row=self.pres_row+6, column = self.pres_col+2, sticky=W+E)
			self.pres_ils_answer.config(stat='readonly')

			#imparfait
			self.imp_je_answer = Entry(self.center,width=ent_width)
			self.imp_je_answer.grid(row=self.imp_row+1, column = self.imp_col+2)
			self.imp_je_answer.config(stat='readonly')
			self.imp_tu_answer = Entry(self.center,width=ent_width)
			self.imp_tu_answer.grid(row=self.imp_row+2, column = self.imp_col+2, sticky=W+E)
			self.imp_tu_answer.config(stat='readonly')
			self.imp_il_answer = Entry(self.center,width=ent_width)
			self.imp_il_answer.grid(row=self.imp_row+3, column = self.imp_col+2, sticky=W+E)
			self.imp_il_answer.config(stat='readonly')
			self.imp_n_answer = Entry(self.center,width=ent_width)
			self.imp_n_answer.grid(row=self.imp_row+4, column = self.imp_col+2, sticky=W+E)
			self.imp_n_answer.config(stat='readonly')
			self.imp_v_answer = Entry(self.center,width=ent_width)
			self.imp_v_answer.grid(row=self.imp_row+5, column = self.imp_col+2, sticky=W+E)
			self.imp_v_answer.config(stat='readonly')
			self.imp_ils_answer = Entry(self.center,width=ent_width)
			self.imp_ils_answer.grid(row=self.imp_row+6, column = self.imp_col+2, sticky=W+E)


			#subj
			self.subj_je_answer = Entry(self.center,width=ent_width)
			self.subj_je_answer.grid(row=self.subj_row+1, column = self.subj_col+2)
			self.subj_tu_answer = Entry(self.center,width=ent_width)
			self.subj_tu_answer.grid(row=self.subj_row+2, column = self.subj_col+2, sticky=W+E)
			self.subj_il_answer = Entry(self.center,width=ent_width)
			self.subj_il_answer.grid(row=self.subj_row+3, column = self.subj_col+2, sticky=W+E)
			self.subj_n_answer = Entry(self.center,width=ent_width)
			self.subj_n_answer.grid(row=self.subj_row+4, column = self.subj_col+2, sticky=W+E)
			self.subj_v_answer = Entry(self.center,width=ent_width)
			self.subj_v_answer.grid(row=self.subj_row+5, column = self.subj_col+2, sticky=W+E)
			self.subj_ils_answer = Entry(self.center,width=ent_width)
			self.subj_ils_answer.grid(row=self.subj_row+6, column = self.subj_col+2, sticky=W+E)
			

			

			#fut
			self.fut_je_answer = Entry(self.center,width=ent_width)
			self.fut_je_answer.grid(row=self.fut_row+1, column = self.fut_col+2)
			self.fut_tu_answer = Entry(self.center,width=ent_width)
			self.fut_tu_answer.grid(row=self.fut_row+2, column = self.fut_col+2, sticky=W+E)
			self.fut_il_answer = Entry(self.center,width=ent_width)
			self.fut_il_answer.grid(row=self.fut_row+3, column = self.fut_col+2, sticky=W+E)
			self.fut_n_answer = Entry(self.center,width=ent_width)
			self.fut_n_answer.grid(row=self.fut_row+4, column = self.fut_col+2, sticky=W+E)
			self.fut_v_answer = Entry(self.center,width=ent_width)
			self.fut_v_answer.grid(row=self.fut_row+5, column = self.fut_col+2, sticky=W+E)
			self.fut_ils_answer = Entry(self.center,width=ent_width)
			self.fut_ils_answer.grid(row=self.fut_row+6, column = self.fut_col+2, sticky=W+E)
			
		

			#cond
			self.cond_je_answer = Entry(self.center,width=ent_width)
			self.cond_je_answer.grid(row=self.cond_row+1, column = self.cond_col+2)
			self.cond_tu_answer = Entry(self.center,width=ent_width)
			self.cond_tu_answer.grid(row=self.cond_row+2, column = self.cond_col+2, sticky=W+E)
			self.cond_il_answer = Entry(self.center,width=ent_width)
			self.cond_il_answer.grid(row=self.cond_row+3, column = self.cond_col+2, sticky=W+E)
			self.cond_n_answer = Entry(self.center,width=ent_width)
			self.cond_n_answer.grid(row=self.cond_row+4, column = self.cond_col+2, sticky=W+E)
			self.cond_v_answer = Entry(self.center,width=ent_width)
			self.cond_v_answer.grid(row=self.cond_row+5, column = self.cond_col+2, sticky=W+E)
			self.cond_ils_answer = Entry(self.center,width=ent_width)
			self.cond_ils_answer.grid(row=self.cond_row+6, column = self.cond_col+2, sticky=W+E)

			
			
			#imper
			self.imper_tu_answer = Entry(self.center,width=ent_width)
			self.imper_tu_answer.grid(row=self.imper_row+1, column = self.imper_col+2, sticky=W+E)
			self.imper_n_answer = Entry(self.center,width=ent_width)
			self.imper_n_answer.grid(row=self.imper_row+2, column = self.imper_col+2, sticky=W+E)
			self.imper_v_answer = Entry(self.center,width=ent_width)
			self.imper_v_answer.grid(row=self.imper_row+3, column = self.imper_col+2, sticky=W+E)
			


			#pc
			self.pc_answer = Entry(self.center,width=ent_width)
			self.pc_answer.grid(row=self.pc_row+1, column = self.pc_col+2)
		
		#PC CHECK BTN
#		self.pc_check_btn = Button(self.center, text='check')
#		self.pc_check_btn.grid(row=self.pc_row+2, column=self.pc_col+2, sticky=E)
#		self.pc_check_btn.bind('<Button-1>', self.pc_check_func)

		
		
		'''BUTTONS!!'''
		self.btn_col = 99
		self.btn_width = 5
		
#		self.btn_canvas = Canvas(self.root)
#		self.btn_canvas.grid(row=99,column=99)
		
		if self.ISPRACTICE:
			self.check_all_btn = Button(self.check_bx_frame, text=u"\u2713", fg='green')
			self.check_all_btn.config(font=('Arial bold', 20))
			self.check_all_btn.grid(row=0,column=8, sticky = 'se')
	#		check_all_btn.place(relx=.99,rely=.89, anchor=SE) #TEMPORARY
			self.check_all_btn.bind('<Button-1>', self.check_all_btn_func)
			
			self.answer_btn = Button(self.check_bx_frame, text='A')
			self.answer_btn.config(font=('Arial bold', 17))
			self.answer_btn.grid(row=0,column=9, sticky = 'se')
	#		answer_btn.place(relx=.99,rely=.93, anchor=SE) #TEMPORARY
			self.answer_btn.bind('<Button-1>', self.answer_btn_func)
			
			self.back_btn = Button(self.check_bx_frame, text='◀', highlightbackground='white')
			self.back_btn.grid(row=0,column=10, sticky='sw')
			
	#		self.back_btn.place(relx=.3,rely=.55) #TEMPORARY
			self.back_btn.bind('<Button-1>', self.back_btn_func)

				
		
		self.next_btn = Button(self.check_bx_frame, text='▶', highlightbackground='white')
#		self.next_btn.place(relx = .345, rely = .55)
		self.next_btn.grid(row=0,column=11, sticky=S+E)
		self.next_btn.bind('<Button-1>', self.next_btn_func)
		
		if not self.ISPRACTICE:
			try:
				self.finish_test_btn.destroy()
			except:
				pass
				
			self.finish_test_btn = Button(self.check_bx_frame, text='Finish', command=self.submit_test)
			self.finish_test_btn.grid(row=0,column=10)
			
			if self.vbs_counter == len(self.vbs)-1:
				print('FINISH BTN SHOW')
				self.root.unbind('<Right>')
				self.next_btn.destroy()
		else:
			try:
				self.finish_test_btn.destroy()
			except:
				pass
				
		blank_btn_lbl = Label(self.check_bx_frame, width=2, bg='white')
		blank_btn_lbl.grid(row=0, column=12)
		
		self.init_entries()
		for i in self.entries:
			try:
				answer = i[0]
				answer.config(state='readonly')
			except Exception as e:
				print(e)
				
	def destroyer(self):
#		lbls = [
#			self.present_label, self.pres_je_label, self.pres_tu_label, self.pres_il_label, self.pres_n_label, self.pres_v_label, self.pres_ils_label,
#			self.imp_label, self.imp_je_label, self.imp_tu_label, self.imp_il_label, self.imp_n_label, self.imp_v_label, self.imp_ils_label
#		]
#		
#		try:
#			for i in lbls:
#				i.destroy()
#		except:
#			pass			
		try:
			for i in self.entries:
				i[0].destroy()
		except:
			pass
		try:
			for i in self.entries:
				i[1].destroy()
		except:
			pass

		try:
			self.answer_btn.destroy()
			self.check_all_btn.destroy()
			self.back_btn.destroy()
		except:
			pass
		try:
			self.next_btn.destroy()
		except:
			pass	
		try:
			self.search_entry_label.destroy()
			self.search_entry.destroy()
		except:
			pass
		try:
			self.main_label.destroy()
			self.main_my_name.destroy()
			self.main_start_btn.destroy()
			self.main_start_btn.destroy()
		except:
			pass
		try:
			self.img1.destroy()
		except:
			pass
		try:
			lbls = [self.pres_je_label,
					self.pres_tu_label,
					self.pres_il_label,
					self.pres_n_label,
					self.pres_v_label,
					self.pres_ils_label,
					self.imp_je_label,
					self.imp_tu_label,
					self.imp_il_label,
					self.imp_n_label,
					self.imp_v_label, 
					self.imp_ils_label, 
					self.fut_je_label, 
					self.fut_tu_label, 
					self.fut_il_label, 
					self.fut_n_label, 
					self.fut_v_label, 
					self.fut_ils_label, 
					self.cond_je_label, 
					self.cond_tu_label,  
					self.cond_il_label, 
					self.cond_n_label, 
					self.cond_v_label, 
					self.cond_ils_label, 
					self.subj_je_label, 
					self.subj_tu_label, 
					self.subj_il_label, 
					self.subj_n_label, 
					self.subj_v_label, 
					self.subj_ils_label, 
					self.imper_tu_label, 
					self.imper_n_label, 
					self.imper_v_label,  
					self.pc_label,
					self.present_label,
					self.subj_label,
					self.imp_label,
					self.fut_label,
					self.imper_label,
					self.subj_label,
					self.pc_pc_label,
					self.cond_label
					]
			for i in lbls:
				try:
					i.destroy()
				except:
					pass
		except:
			pass	
			
	def submit_test(self):
		self.SUB = True
		try:
			self.subcolor = self.new_color
		except:
			self.subcolor = self.default_color
		if messagebox.askyesno('', 'Submit test answers?'):
			self.save_test_answers()
			message = ''
			x = 5

			self.vbs_counter = 0
			self.exited_test = True

			#window
			correct = self.correct_counter
			wrong = self.incorrect_counter
			total = correct + wrong
			try:
				percent = round((correct/total)*100)
			except ZeroDivisionError:
				percent = 0

			self.top_frame.destroy()
#			self.btm_frame.destroy()
			try:
				self.practice_lbl.destroy()
				self.test_btn.destroy()
			except Exception as e:
				print(e)
			try:
				self.practice_btn.destroy()
				self.test_lbl.destroy()
			except Exception as e:
				print(e)
				
			try:
				self.next_btn.destroy()
				self.finish_test_btn.destroy()
			except Exception as e:
				print(e)
			self.center.destroy()
			self.search_frame.destroy()
#			self.check_bx_frame.destroy()


			self.sw_top = Frame(self.root, bg='white')
			self.sw_bot = Frame(self.root, bg='white')
			
			self.sw_top.grid(row=0,column=0, sticky='nsew')
			self.sw_bot.grid(row=1,column=0, sticky='nsew')

			self.stats_lbl = Label(self.sw_top, text='Test Results')
			self.stats_lbl.config(font=('Arial bold', 25))			
			
			
			self.wron_list = []
			for i in self.test_incorrect_list:
				verb = i[0]
				conj = i[1]
				corr = i[2]
				wron = i[3]
				
				self.wron_list.append(wron)
				
				if 'pres_' in conj:
					tens1 = 'Present'
				elif 'imp_' in conj:
					tens1 = 'Imparfait'
				elif 'subj_' in conj:
					tens1 = 'Subjunctive'
				elif 'fut_' in conj:
					tens1 = 'Future'
				elif 'cond_' in conj:
					tens1 = 'Conditional'
				elif 'imper_' in conj:
					tens1 = 'Imperative'
				elif 'pc' in conj:
					tens1 = 'Passé Composé'
				
				if '_je' in conj:
					tens2 = 'Je/J\''
				elif '_tu' in conj:
					tens2 = 'Tu'
				elif '_il' in conj:
					tens2 = 'Il/Elle'	
				elif '_n' in conj:
					tens2 = 'Nous'	
				elif '_v' in conj:
					tens2 = 'Vous'	
				elif '_ils' in conj:
					tens2 = 'Ils/Elles'	
					
				
				vb_cap = '\n'+verb.capitalize()
				
				try:
					if verb == self.last_vb:
						vb_cap = ' '*(len(verb))
					else:
						vb_cap = '\n'+verb.capitalize()
						
				except Exception as e:
					print(e)

				tens1_t = tens1

				add_wrong = '{}\t\t{}\t\t    {}\t\t    {}\t\t      {}\n'.format(vb_cap, 
				tens1_t.capitalize(), tens2.capitalize(), corr, wron)
				message += add_wrong	
				
				self.last_vb = verb
			
			
			self.wrong_box = Text(self.sw_bot, width=84, height=32, highlightthickness=0)
			self.wrong_box.delete('1.0', END)
			self.wrong_box.insert('1.0', message)

#			self.wrong_box.tag_configure('name', font=('Arial bold', 13))
#			self.wrong_box.tag_config('wrong', foreground="red")
			

			self.wrong_box.config(font=('Arial', 15), state=DISABLED)
			self.percent_lbl1 = Label(self.sw_top, text='Percent:')
			self.percent_lbl1.config(font=('Arial bold', 15))
			self.percent_lbl2 = Label(self.sw_top, text='{}%'.format(percent))
			self.wrong_lbl1 = Label(self.sw_top, text='Wrong:')
			self.wrong_lbl1.config(font=('Arial bold', 15))
			self.wrong_lbl2 = Label(self.sw_top, text=wrong)
			self.correct_lbl1 = Label(self.sw_top, text='Correct:')
			self.correct_lbl1.config(font=('Arial bold', 15))
			self.correct_lbl2 = Label(self.sw_top, text=correct)
			self.total_lbl1 = Label(self.sw_top, text='Total:')
			self.total_lbl1.config(font=('Arial bold', 15))
			self.total_lbl2 = Label(self.sw_top, text=total)
			self.error_lbl = Label(self.sw_top, text='Errors:')
			self.error_lbl.config(font=('Arial bold', 15))

			r = 1
			c = 0
#			self.stats_lbl.grid(row=0, column=1)
			self.stats_lbl.place(relx=.41, rely=.175)
#			Label(self.sw_top, width=20, height=10).grid(row=r, column=c)
			self.correct_lbl1.grid(row=r+1, column=c, sticky='e')
			self.correct_lbl2.grid(row=r+1, column=c+1, sticky='w')
			self.total_lbl1.grid(row=r+2, column=c, sticky='e')
			self.total_lbl2.grid(row=r+2, column=c+1, sticky='w')
#			self.wrong_lbl1.grid(row=, column=)
#			self.wrong_lbl2.grid(row=, column=)
			self.percent_lbl1.grid(row=r+3, column=c, sticky='e')
			self.percent_lbl2.grid(row=r+3, column=c+1, sticky='w')
			self.error_lbl.grid(row=r+4, column=c, sticky='ne')
			
			self.lbl21 = Label(self.sw_top, height=6, width=0)
			self.lbl21.grid(row=0, column=0)
			w = 16
			self.lbl11 = Label(self.sw_bot, text='', width=11) #
			self.lbl11.grid(row=0, column=0)
			self.wrong_box.grid(row=0, column=1, sticky='nsew')		
			self.lbl00 = Label(self.sw_top, width=4) #
			self.lbl00.grid(row=r+4, column=c+1)	
			self.lbl01 = Label(self.sw_top, text='Verb', width=w, anchor='w')
			self.lbl01.config(font=('Arial bold', 13))
			self.lbl01.grid(row=r+4, column=c+2, sticky='s')
			self.lbl02 = Label(self.sw_top, text='Tense', width=w, anchor='w')
			self.lbl02.config(font=('Arial bold', 13))
			self.lbl02.grid(row=r+4, column=c+3, sticky='s')
			self.lbl03 = Label(self.sw_top, text='Subject', width=w, anchor='w')
			self.lbl03.config(font=('Arial bold', 13))
			self.lbl03.grid(row=r+4, column=c+4, sticky='s')
			self.lbl04 = Label(self.sw_top, text='Correct', width=w, anchor='w')
			self.lbl04.config(font=('Arial bold', 13))
			self.lbl04.grid(row=r+4, column=c+5, sticky='s')
			self.lbl05 = Label(self.sw_top, text='Your Answer', width=w, anchor='w')
			self.lbl05.config(font=('Arial bold', 13))
			self.lbl05.grid(row=r+4, column=c+6, sticky='s')
#			self.lbl06 = Label(self.sw_top, text='Tense', width=w)
#			self.lbl06.config(font=('Arial bold', 13))
#			self.lbl06.grid(row=r+4, column=c+2, sticky='ne')
			
			
			
			self.done_btn = Button(self.check_bx_frame, text='Done', command=self.pressed_done)
			self.done_btn.grid(row=1, column=1)
			
			try:
				self.done_btn['bg'] = self.new_color
			except:
				self.done_btn['bg'] = self.default_color
			
			self.sw_top['bg'] = self.subcolor
			self.sw_bot['bg'] = self.subcolor
			for child in self.sw_top.winfo_children():
				child['bg'] = self.subcolor
			for child in self.sw_bot.winfo_children():
				child['bg'] = self.subcolor
		
			try:	
				self.btm_frame['bg'] = self.new_color
				self.check_bx_frame['bg'] = self.new_color
				for child in self.btm_frame.winfo_children():
					child['bg'] = self.new_color
					child['highlightbackground'] = self.new_color
				for child in self.check_bx_frame.winfo_children():
					child['bg'] = self.new_color
					child['highlightbackground'] = self.new_color
			except:
				self.btm_frame['bg'] = self.default_color
				self.check_bx_frame['bg'] = self.default_color
				for child in self.btm_frame.winfo_children():
					child['bg'] = self.default_color
					child['highlightbackground'] = self.default_color
				for child in self.check_bx_frame.winfo_children():
					child['bg'] = self.default_color
					child['highlightbackground'] = self.default_color
	def pressed_done(self):
		self.sw_top.destroy()
		self.sw_bot.destroy
		self.toggle_test_practice()

	def pres_check_func(self, event):
		print('pres check button pressed')
		
		
	def init_entries(self):
		self.entries = [
						(self.pres_je_answer, self.pres_je_entry, 'pres_je'),
						(self.pres_tu_answer, self.pres_tu_entry, 'pres_tu'),
						(self.pres_il_answer, self.pres_il_entry, 'pres_il'),
						(self.pres_n_answer, self.pres_n_entry, 'pres_n'),
						(self.pres_v_answer, self.pres_v_entry, 'pres_v'),
						(self.pres_ils_answer, self.pres_ils_entry, 'pres_ils'),
						(self.imp_je_answer, self.imp_je_entry, 'imp_je'),
						(self.imp_tu_answer, self.imp_tu_entry, 'imp_tu'),
						(self.imp_il_answer, self.imp_il_entry, 'imp_il'),
						(self.imp_n_answer, self.imp_n_entry, 'imp_n'),
						(self.imp_v_answer, self.imp_v_entry, 'imp_v'),
						(self.imp_ils_answer, self.imp_ils_entry, 'imp_ils'),
						(self.fut_je_answer, self.fut_je_entry, 'fut_je'),
						(self.fut_tu_answer, self.fut_tu_entry, 'fut_tu'),
						(self.fut_il_answer, self.fut_il_entry, 'fut_il'),
						(self.fut_n_answer, self.fut_n_entry, 'fut_n'),
						(self.fut_v_answer, self.fut_v_entry, 'fut_v'),
						(self.fut_ils_answer, self.fut_ils_entry, 'fut_ils'),
						(self.cond_je_answer, self.cond_je_entry, 'cond_je'),
						(self.cond_tu_answer,  self.cond_tu_entry, 'cond_tu'),
						(self.cond_il_answer, self.cond_il_entry, 'cond_il'),
						(self.cond_n_answer,  self.cond_n_entry, 'cond_n'),
						(self.cond_v_answer, self.cond_v_entry, 'cond_v'),
						(self.cond_ils_answer, self.cond_ils_entry, 'cond_ils'),
						(self.subj_je_answer,  self.subj_je_entry, 'subj_je'),
						(self.subj_tu_answer, self.subj_tu_entry, 'subj_tu'),
						(self.subj_il_answer, self.subj_il_entry, 'subj_il'),
						(self.subj_n_answer, self.subj_n_entry, 'subj_n'),
						(self.subj_v_answer, self.subj_v_entry, 'subj_v'),
						(self.subj_ils_answer, self.subj_ils_entry, 'subj_ils'),
						(self.imper_tu_answer, self.imper_tu_entry, 'imper_tu'),
						(self.imper_n_answer, self.imper_n_entry, 'imper_n'),
						(self.imper_v_answer,  self.imper_v_entry, 'imper_v'),
						(self.pc_answer, self.pc_entry, 'pc')
						]
	#BUTTON FUNCTIONS
	def check_all_btn_func(self, event):

		print('check_all btn')
		'''PRESENT CHECKALL'''
			
		self.init_entries()

		ccorrect = 'Correct'
		wwrong =   u'\u274C'
		
		
		for i in self.entries:
			answer = i[0]
			entry = i[1]
			entry_text = entry.get()
			conj = i[2]
			if entry_text == self.vb[conj]:
				is_correct = ccorrect
			elif entry_text == '':
				is_correct = ''
			else:
				is_correct = wwrong
				
			answer.config(state='normal')
			answer.delete(0,'end')
			answer.insert(0, is_correct)
			answer.config(state='readonly')


	def answer_btn_func(self, event):
		print('answer btn')
		self.init_entries()
		
		for i in self.entries:
			answer = i[0]
			answer_text = answer.get()
			conj = i[2]
			
			answer.config(state='normal')
			answer.delete(0,'end')
			answer.insert(0, self.vb[conj])
			answer.config(state='readonly')
					
		
	def init_verbs(self):
		print('init verbs func')
		#create verb vars
		self.avoir = {
		'name':'avoir',		'defn':'to have',	'pc':'avoir eu',
		'pres_je':'ai',		'pres_tu':'as',		'pres_il':'a',
		'pres_n':'avons', 	'pres_v':'avez',	'pres_ils':'ont',
		'imp_je':'avais', 	'imp_tu':'avais',	'imp_il':'avait',
		'imp_n':'avions',	'imp_v':'aviez', 	'imp_ils':'avaient',
		'fut_je':'aurai', 	'fut_tu':'auras',	'fut_il':'aura',
		'fut_n':'aurons',	'fut_v':'aurez',	'fut_ils':'auront',
		'cond_je':'aurais',	'cond_tu':'aurais',	'cond_il':'aurait',
		'cond_n':'aurions',	'cond_v':'auriez',	'cond_ils':'auraient',
		'subj_je':'aie',	'subj_tu':'aies',	'subj_il':'ait',
		'subj_n':'ayons',	'subj_v':'ayez',	'subj_ils':'aient',
		'imper_tu':'aie',	'imper_n':'ayons',	'imper_v':'ayez',
		'boot':False}

		self.aller = {
		'name':'aller',		'defn':'to go',		'pc':'être allé',
		'pres_je':'vais',	'pres_tu':'vas',	'pres_il':'va',
		'pres_n':'allons', 	'pres_v':'allez',	'pres_ils':'vont',
		'imp_je':'allais', 	'imp_tu':'allais',	'imp_il':'allait',
		'imp_n':'allions',	'imp_v':'alliez', 	'imp_ils':'allaient',
		'fut_je':'irai', 	'fut_tu':'iras',	'fut_il':'ira',
		'fut_n':'irons',	'fut_v':'irez',	'fut_ils':'iront',
		'cond_je':'irais',	'cond_tu':'irais',	'cond_il':'irait',
		'cond_n':'irions',	'cond_v':'iriez',	'cond_ils':'iraient',
		'subj_je':'aille',	'subj_tu':'ailles',	'subj_il':'aille',
		'subj_n':'allions',	'subj_v':'alliez',	'subj_ils':'aillent',
		'imper_tu':'va',	'imper_n':'allons',	'imper_v':'allez',
		'boot':True}

		self.pouvoir = {
		'name':'pouvoir', 'defn':'to be able', 'pc':'avoir pu',
		'pres_je':'peux', 'pres_tu':'peux', 'pres_il':'peut',
		'pres_n':'pouvons', 'pres_v':'pouvez','pres_ils':'peuvent',
		'imp_je':'pouvais', 'imp_tu':'pouvais', 'imp_il':'pouvait',
		'imp_n':'pouvions', 'imp_v':'pouviez', 'imp_ils':'pouvaient',
		'fut_je':'pourrai', 'fut_tu':'pourras', 'fut_il':'pourra',
		'fut_n':'pourrons', 'fut_v':'pourrez', 'fut_ils':'pourront',
		'cond_je':'pourrais', 'cond_tu':'pourrais','cond_il':'pourrait',
		'cond_n':'pourrions', 'cond_v':'pourriez', 'cond_ils':'pourraient',
		'subj_je':'puisse', 'subj_tu':'puisses', 'subj_il':'puisse',
		'subj_n':'puissions', 'subj_v':'puissiez', 'subj_ils':'puissent',
		'imper_tu':'-', 'imper_n':'-', 'imper_v':'-',
		'boot':True}

		self.etre = {
		'name':'être', 'defn':'to be', 'pc':'avoir été',
		'pres_je':'suis', 'pres_tu':'es', 'pres_il':'est',
		'pres_n':'sommes', 'pres_v':'êtes','pres_ils':'sont',
		'imp_je':'étais', 'imp_tu':'étais', 'imp_il':'était',
		'imp_n':'étions', 'imp_v':'étiez', 'imp_ils':'étaient',
		'fut_je':'serai', 'fut_tu':'seras', 'fut_il':'sera',
		'fut_n':'serons', 'fut_v':'serez', 'fut_ils':'seront',
		'cond_je':'serais', 'cond_tu':'serais','cond_il':'serait',
		'cond_n':'serions', 'cond_v':'seriez', 'cond_ils':'seraient',
		'subj_je':'sois', 'subj_tu':'sois', 'subj_il':'soit',
		'subj_n':'soyons', 'subj_v':'soyez', 'subj_ils':'soient',
		'imper_tu':'sois', 'imper_n':'soyons', 'imper_v':'soyez',
		'boot':False}


		self.battre = {
		'name':'battre', 'defn':'to beat', 'pc':'avoir battu',
		'pres_je':'bats', 'pres_tu':'bats', 'pres_il':'bat',
		'pres_n':'battons', 'pres_v':'battez','pres_ils':'battent',
		'imp_je':'battais', 'imp_tu':'battais', 'imp_il':'battait',
		'imp_n':'battions', 'imp_v':'battiez', 'imp_ils':'battaient',
		'fut_je':'battrai', 'fut_tu':'battras', 'fut_il':'battra',
		'fut_n':'battrons', 'fut_v':'battrez', 'fut_ils':'battront',
		'cond_je':'battrais', 'cond_tu':'battrais','cond_il':'battrait',
		'cond_n':'battrions', 'cond_v':'battriez', 'cond_ils':'battraient',
		'subj_je':'batte', 'subj_tu':'battes', 'subj_il':'batte',
		'subj_n':'battions', 'subj_v':'battiez', 'subj_ils':'battent',
		'imper_tu':'bats', 'imper_n':'battons', 'imper_v':'battez',
		'boot':False}

		self.croire = {
		'name':'croire', 'defn':'to believe', 'pc':'avoir cru',
		'pres_je':'crois', 'pres_tu':'crois', 'pres_il':'croit',
		'pres_n':'croyons', 'pres_v':'croyez','pres_ils':'croient',
		'imp_je':'croyais', 'imp_tu':'croyais', 'imp_il':'croyait',
		'imp_n':'croyions', 'imp_v':'croyiez', 'imp_ils':'croyaient',
		'fut_je':'croirai', 'fut_tu':'croiras', 'fut_il':'croira',
		'fut_n':'croirons', 'fut_v':'croirez', 'fut_ils':'croiront',
		'cond_je':'croirais', 'cond_tu':'croirais','cond_il':'croirait',
		'cond_n':'croirions', 'cond_v':'croiriez', 'cond_ils':'croiraient',
		'subj_je':'croie', 'subj_tu':'croies', 'subj_il':'croie',
		'subj_n':'croyions', 'subj_v':'croyiez', 'subj_ils':'croient',
		'imper_tu':'crois', 'imper_n':'croyons', 'imper_v':'croyez',
		'boot':True}

		self.mourir = {
		'name':'mourir', 'defn':'to die', 'pc':'être mort',
		'pres_je':'meurs', 'pres_tu':'meurs', 'pres_il':'meurt',
		'pres_n':'mourons', 'pres_v':'mourez','pres_ils':'meurent',
		'imp_je':'mourais', 'imp_tu':'mourais', 'imp_il':'mourait',
		'imp_n':'mourions', 'imp_v':'mouriez', 'imp_ils':'mouraient',
		'fut_je':'mourrai', 'fut_tu':'mourras', 'fut_il':'mourra',
		'fut_n':'mourrons', 'fut_v':'mourrez', 'fut_ils':'mourront',
		'cond_je':'mourrais', 'cond_tu':'mourrais','cond_il':'mourrait',
		'cond_n':'mourrions', 'cond_v':'mourriez', 'cond_ils':'mourraient',
		'subj_je':'meure', 'subj_tu':'meures', 'subj_il':'meure',
		'subj_n':'mourions', 'subj_v':'mouriez', 'subj_ils':'meurent',
		'imper_tu':'meurs', 'imper_n':'mourons', 'imper_v':'mourez',
		'boot':True}

		self.faire = {
		'name':'faire', 'defn':'to do', 'pc':'avoir fait',
		'pres_je':'fais', 'pres_tu':'fais', 'pres_il':'fait',
		'pres_n':'faisons', 'pres_v':'faites','pres_ils':'font',
		'imp_je':'faisais', 'imp_tu':'faisais', 'imp_il':'faisait',
		'imp_n':'faisions', 'imp_v':'faisiez', 'imp_ils':'faisaient',
		'fut_je':'ferai', 'fut_tu':'feras', 'fut_il':'fera',
		'fut_n':'ferons', 'fut_v':'ferez', 'fut_ils':'feront',
		'cond_je':'ferais', 'cond_tu':'ferais','cond_il':'ferait',
		'cond_n':'ferions', 'cond_v':'feriez', 'cond_ils':'feraient',
		'subj_je':'fasse', 'subj_tu':'fasses', 'subj_il':'fasse',
		'subj_n':'fassions', 'subj_v':'fassiez', 'subj_ils':'fassent',
		'imper_tu':'fais', 'imper_n':'faisons', 'imper_v':'faites',
		'boot':False}

		self.boire = {
		'name':'boire', 'defn':'to drink', 'pc':'avoir bu',
		'pres_je':'bois', 'pres_tu':'bois', 'pres_il':'boit',
		'pres_n':'buvons', 'pres_v':'buvez','pres_ils':'boivent',
		'imp_je':'buvais', 'imp_tu':'buvais', 'imp_il':'buvait',
		'imp_n':'buvions', 'imp_v':'buviez', 'imp_ils':'buvaient',
		'fut_je':'boirai', 'fut_tu':'boiras', 'fut_il':'boira',
		'fut_n':'boirons', 'fut_v':'boirez', 'fut_ils':'boiront',
		'cond_je':'boirais', 'cond_tu':'boirais','cond_il':'boirait',
		'cond_n':'boirions', 'cond_v':'boiriez', 'cond_ils':'boiraient',
		'subj_je':'boive', 'subj_tu':'boives', 'subj_il':'boive',
		'subj_n':'buvions', 'subj_v':'buviez', 'subj_ils':'boivent',
		'imper_tu':'bois', 'imper_n':'buvons', 'imper_v':'buvez',
		'boot':True}

		self.conduire = {
		'name':'conduire', 'defn':'to drive', 'pc':'avoir conduit',
		'pres_je':'conduis', 'pres_tu':'conduis', 'pres_il':'conduit',
		'pres_n':'conduisons', 'pres_v':'conduisez','pres_ils':'conduisent',
		'imp_je':'conduisais', 'imp_tu':'conduisais', 'imp_il':'conduisait',
		'imp_n':'conduisions', 'imp_v':'conduisiez', 'imp_ils':'conduisaient',
		'fut_je':'conduirai', 'fut_tu':'conduiras', 'fut_il':'conduira',
		'fut_n':'conduirons', 'fut_v':'conduirez', 'fut_ils':'conduiront',
		'cond_je':'conduirais', 'cond_tu':'conduirais','cond_il':'conduirait',
		'cond_n':'conduirions', 'cond_v':'conduiriez', 'cond_ils':'conduiraient',
		'subj_je':'conduise', 'subj_tu':'conduises', 'subj_il':'conduise',
		'subj_n':'conduisions', 'subj_v':'conduisiez', 'subj_ils':'conduisent',
		'imper_tu':'conduis', 'imper_n':'conduisons', 'imper_v':'conduisez',
		'boot':True}

		self.craindre = {
		'name':'craindre', 'defn':'to fear', 'pc':'avoir craint',
		'pres_je':'crains', 'pres_tu':'crains', 'pres_il':'craint',
		'pres_n':'craignons', 'pres_v':'craignez','pres_ils':'craignent',
		'imp_je':'craignais', 'imp_tu':'craignais', 'imp_il':'craignait',
		'imp_n':'craignions', 'imp_v':'craigniez', 'imp_ils':'craignaient',
		'fut_je':'craindrai', 'fut_tu':'craindras', 'fut_il':'craindra',
		'fut_n':'craindrons', 'fut_v':'craindrez', 'fut_ils':'craindront',
		'cond_je':'craindrais', 'cond_tu':'craindrais','cond_il':'craindrait',
		'cond_n':'craindrions', 'cond_v':'craindriez', 'cond_ils':'craindraient',
		'subj_je':'craigne', 'subj_tu':'craignes', 'subj_il':'craigne',
		'subj_n':'craigions', 'subj_v':'craigniez', 'subj_ils':'craignaient',
		'imper_tu':'crains', 'imper_n':'craignons', 'imper_v':'craignez',
		'boot':False}

		self.suivre = {
		'name':'suivre', 'defn':'to follow', 'pc':'avoir suivi',
		'pres_je':'suis', 'pres_tu':'suis', 'pres_il':'suit',
		'pres_n':'suivons', 'pres_v':'suivez','pres_ils':'suivent',
		'imp_je':'suivais', 'imp_tu':'suivais', 'imp_il':'suivait',
		'imp_n':'suivions', 'imp_v':'suiviez', 'imp_ils':'suivaient',
		'fut_je':'suivrai', 'fut_tu':'suivras', 'fut_il':'suivra',
		'fut_n':'suivrons', 'fut_v':'suivrez', 'fut_ils':'suivront',
		'cond_je':'suivrais', 'cond_tu':'suivrais','cond_il':'suivrait',
		'cond_n':'suivrions', 'cond_v':'suivriez', 'cond_ils':'suivraient',
		'subj_je':'suive', 'subj_tu':'suives', 'subj_il':'suive',
		'subj_n':'suivions', 'subj_v':'suiviez', 'subj_ils':'suivent',
		'imper_tu':'suis', 'imper_n':'suivons', 'imper_v':'suivez',
		'boot':False}

		self.devoir = {
		'name':'devoir', 'defn':'to have to', 'pc':'avoir dû',
		'pres_je':'dois', 'pres_tu':'dois', 'pres_il':'doit',
		'pres_n':'devons', 'pres_v':'devez','pres_ils':'doivent',
		'imp_je':'devais', 'imp_tu':'devais', 'imp_il':'devait',
		'imp_n':'devions', 'imp_v':'deviez', 'imp_ils':'devaient',
		'fut_je':'devrai', 'fut_tu':'devras', 'fut_il':'devra',
		'fut_n':'devrons', 'fut_v':'devrez', 'fut_ils':'devront',
		'cond_je':'devrais', 'cond_tu':'devrais','cond_il':'devrait',
		'cond_n':'devrions', 'cond_v':'devriez', 'cond_ils':'devraient',
		'subj_je':'doive', 'subj_tu':'doives', 'subj_il':'doive',
		'subj_n':'devions', 'subj_v':'deviez', 'subj_ils':'doivent',
		'imper_tu':'dois', 'imper_n':'devons', 'imper_v':'devez',
		'boot':True}

		self.tenir = {
		'name':'tenir', 'defn':'to hold', 'pc':'avoir tenu',
		'pres_je':'tiens', 'pres_tu':'tiens', 'pres_il':'tient',
		'pres_n':'tenons', 'pres_v':'tenez','pres_ils':'tiennent',
		'imp_je':'tenais', 'imp_tu':'tenais', 'imp_il':'tenait',
		'imp_n':'tenions', 'imp_v':'teniez', 'imp_ils':'tenaient',
		'fut_je':'tiendrai', 'fut_tu':'tiendras', 'fut_il':'tiendra',
		'fut_n':'tiendrons', 'fut_v':'tiendrez', 'fut_ils':'tiendront',
		'cond_je':'tiendrais', 'cond_tu':'tiendrais','cond_il':'tiendrait',
		'cond_n':'tiendrions', 'cond_v':'tiendriez', 'cond_ils':'tiendraient',
		'subj_je':'tienne', 'subj_tu':'tiennes', 'subj_il':'tienne',
		'subj_n':'tenions', 'subj_v':'teniez', 'subj_ils':'tiennent',
		'imper_tu':'tiens', 'imper_n':'tenons', 'imper_v':'tenez',
		'boot':True}

		self.setaire = {
		'name':'se taire', 'defn':'to be quiet', 'pc':'être tu',
		'pres_je':'me tais', 'pres_tu':'te tais', 'pres_il':'se tait',
		'pres_n':'nous taisons', 'pres_v':'vous taisez','pres_ils':'se taisent',
		'imp_je':'me taisais', 'imp_tu':'te taisais', 'imp_il':'se taisait',
		'imp_n':'nous taisions', 'imp_v':'vous taisiez', 'imp_ils':'se taisaient',
		'fut_je':'me tairai', 'fut_tu':'te tairas', 'fut_il':'se taira',
		'fut_n':'nous tairons', 'fut_v':'vous tairez', 'fut_ils':'se tairont',
		'cond_je':'me tairais', 'cond_tu':'te tairais','cond_il':'se tairait',
		'cond_n':'nous tairions', 'cond_v':'vous tairiez', 'cond_ils':'se tairaient',
		'subj_je':'me taise', 'subj_tu':'te taises', 'subj_il':'se taise',
		'subj_n':'nous taisions', 'subj_v':'vous taisiez', 'subj_ils':'se taisent',
		'imper_tu':'tais-toi', 'imper_n':'taisons-nous', 'imper_v':'taisez-vous',
		'boot':True}

		self.connaitre = {
		'name':'connaître', 'defn':'to know', 'pc':'avoir connu',
		'pres_je':'connais', 'pres_tu':'connais', 'pres_il':'connaît',
		'pres_n':'connaissons', 'pres_v':'connaissez','pres_ils':'connaissent',
		'imp_je':'connaissais', 'imp_tu':'connaissais', 'imp_il':'connaissait',
		'imp_n':'connaissions', 'imp_v':'connaissiez', 'imp_ils':'connaissaient',
		'fut_je':'connaîtrai', 'fut_tu':'connaîtras', 'fut_il':'connaîtra',
		'fut_n':'connaîtrons', 'fut_v':'connaîtrez', 'fut_ils':'connaîtront',
		'cond_je':'connaîtrais', 'cond_tu':'connaîtrais','cond_il':'connaîtrait',
		'cond_n':'connaîtrions', 'cond_v':'connaîtriez', 'cond_ils':'connaîtraient',
		'subj_je':'connaisse', 'subj_tu':'connaisses', 'subj_il':'connaisse',
		'subj_n':'connaissions', 'subj_v':'connaissiez', 'subj_ils':'connaissent',
		'imper_tu':'connais', 'imper_n':'connaissons', 'imper_v':'connaissez',
		'boot':True}

		self.savoir = {
		'name':'savoir', 'defn':'to know how', 'pc':'avoir su',
		'pres_je':'sais', 'pres_tu':'sais', 'pres_il':'sait',
		'pres_n':'savons', 'pres_v':'savez','pres_ils':'savent',
		'imp_je':'savais', 'imp_tu':'savais', 'imp_il':'savait',
		'imp_n':'savions', 'imp_v':'saviez', 'imp_ils':'savaient',
		'fut_je':'saurai', 'fut_tu':'sauras', 'fut_il':'saura',
		'fut_n':'saurons', 'fut_v':'saurez', 'fut_ils':'sauront',
		'cond_je':'saurais', 'cond_tu':'saurais','cond_il':'saurait',
		'cond_n':'saurions', 'cond_v':'sauriez', 'cond_ils':'sauraient',
		'subj_je':'sache', 'subj_tu':'saches', 'subj_il':'sache',
		'subj_n':'sachions', 'subj_v':'sachiez', 'subj_ils':'sachent',
		'imper_tu':'sache', 'imper_n':'sachons', 'imper_v':'sachez',
		'boot':False}

		self.rire = {
		'name':'rire', 'defn':'to laugh', 'pc':'avoir ri',
		'pres_je':'ris', 'pres_tu':'ris', 'pres_il':'rit',
		'pres_n':'rions', 'pres_v':'riez','pres_ils':'rient',
		'imp_je':'riais', 'imp_tu':'riais', 'imp_il':'riait',
		'imp_n':'riions', 'imp_v':'riiez', 'imp_ils':'riaient',
		'fut_je':'rirai', 'fut_tu':'riras', 'fut_il':'rira',
		'fut_n':'rirons', 'fut_v':'rirez', 'fut_ils':'riront',
		'cond_je':'rirais', 'cond_tu':'rirais','cond_il':'rirait',
		'cond_n':'ririons', 'cond_v':'ririez', 'cond_ils':'riraient',
		'subj_je':'rie', 'subj_tu':'ries', 'subj_il':'rie',
		'subj_n':'riions', 'subj_v':'riiez', 'subj_ils':'rient',
		'imper_tu':'ris', 'imper_n':'rions', 'imper_v':'riez',
		'boot':True}

		self.vivre = {
		'name':'vivre', 'defn':'to live', 'pc':'avoir vécu',
		'pres_je':'vis', 'pres_tu':'vis', 'pres_il':'vit',
		'pres_n':'vivons', 'pres_v':'vivez','pres_ils':'vivent',
		'imp_je':'vivais', 'imp_tu':'vivais', 'imp_il':'vivait',
		'imp_n':'vivions', 'imp_v':'viviez', 'imp_ils':'vivaient',
		'fut_je':'vivrai', 'fut_tu':'vivras', 'fut_il':'vivra',
		'fut_n':'vivrons', 'fut_v':'vivrez', 'fut_ils':'vivront',
		'cond_je':'vivrais', 'cond_tu':'vivrais','cond_il':'vivrait',
		'cond_n':'vivrions', 'cond_v':'vivriez', 'cond_ils':'vivraient',
		'subj_je':'vive', 'subj_tu':'vives', 'subj_il':'vive',
		'subj_n':'vivions', 'subj_v':'viviez', 'subj_ils':'vivent',
		'imper_tu':'vis', 'imper_n':'vivons', 'imper_v':'vivez',
		'boot':False}

		self.falloir = {
		'name':'falloir', 'defn':'to be necessary', 'pc':'avoir fallu',
		'pres_je':'-', 'pres_tu':'-', 'pres_il':'faut',
		'pres_n':'-', 'pres_v':'-','pres_ils':'-',
		'imp_je':'-', 'imp_tu':'-', 'imp_il':'fallait',
		'imp_n':'-', 'imp_v':'-', 'imp_ils':'-',
		'fut_je':'-', 'fut_tu':'-', 'fut_il':'faudra',
		'fut_n':'-', 'fut_v':'-', 'fut_ils':'-',
		'cond_je':'-', 'cond_tu':'-','cond_il':'faudrait',
		'cond_n':'-', 'cond_v':'-', 'cond_ils':'-',
		'subj_je':'-', 'subj_tu':'-', 'subj_il':'faille',
		'subj_n':'-', 'subj_v':'-', 'subj_ils':'-',
		'imper_tu':'-', 'imper_n':'-', 'imper_v':'-',
		'boot':False}

		self.ouvrir = {
		'name':'ouvrir', 'defn':'to open', 'pc':'avoir ouvert',
		'pres_je':'ouvre', 'pres_tu':'ouvres', 'pres_il':'ouvre',
		'pres_n':'ouvrons', 'pres_v':'ouvrez','pres_ils':'ouvrent',
		'imp_je':'ouvrais', 'imp_tu':'ouvrais', 'imp_il':'ouvrait',
		'imp_n':'ouvrions', 'imp_v':'ouvriez', 'imp_ils':'ouvraient',
		'fut_je':'ouvrirai', 'fut_tu':'ouvriras', 'fut_il':'ouvrira',
		'fut_n':'ouvrirons', 'fut_v':'ouvrirez', 'fut_ils':'ouvriront',
		'cond_je':'ouvrirais', 'cond_tu':'ouvrirais','cond_il':'ouvrirait',
		'cond_n':'ouvririons', 'cond_v':'ouvririez', 'cond_ils':'ouvriraient',
		'subj_je':'ouvre', 'subj_tu':'ouvres', 'subj_il':'ouvre',
		'subj_n':'ouvrions', 'subj_v':'ouvriez', 'subj_ils':'ouvrent',
		'imper_tu':'ouvre', 'imper_n':'ouvrons', 'imper_v':'ouvrez',
		'boot':False}

		self.plaire = {
		'name':'plaire', 'defn':'to please', 'pc':'avoir plu',
		'pres_je':'plais', 'pres_tu':'plais', 'pres_il':'plaît',
		'pres_n':'plaisons', 'pres_v':'plaisez','pres_ils':'plaisent',
		'imp_je':'plaisais', 'imp_tu':'plaisais', 'imp_il':'plaisait',
		'imp_n':'plaisions', 'imp_v':'plaisiez', 'imp_ils':'plaisaient',
		'fut_je':'plairai', 'fut_tu':'plairas', 'fut_il':'plaira',
		'fut_n':'plairons', 'fut_v':'plairez', 'fut_ils':'plairont',
		'cond_je':'plairais', 'cond_tu':'plairais','cond_il':'plairait',
		'cond_n':'plairions', 'cond_v':'plairiez', 'cond_ils':'plairaient',
		'subj_je':'plaise', 'subj_tu':'plaises', 'subj_il':'plaise',
		'subj_n':'plaisions', 'subj_v':'plaisiez', 'subj_ils':'plaisent',
		'imper_tu':'plais', 'imper_n':'plaisons', 'imper_v':'plaisez',
		'boot':False}

		self.mettre = {
		'name':'mettre', 'defn':'to put on', 'pc':'avoir mis',
		'pres_je':'mets', 'pres_tu':'mets', 'pres_il':'met',
		'pres_n':'mettons', 'pres_v':'mettez','pres_ils':'mettent',
		'imp_je':'mettais', 'imp_tu':'mettais', 'imp_il':'mettait',
		'imp_n':'mettions', 'imp_v':'mettiez', 'imp_ils':'mettaient',
		'fut_je':'mettrai', 'fut_tu':'mettras', 'fut_il':'mettra',
		'fut_n':'mettrons', 'fut_v':'mettrez', 'fut_ils':'mettront',
		'cond_je':'mettrais', 'cond_tu':'mettrais','cond_il':'mettrait',
		'cond_n':'mettrions', 'cond_v':'mettriez', 'cond_ils':'mettraient',
		'subj_je':'mette', 'subj_tu':'mettes', 'subj_il':'mette',
		'subj_n':'mettions', 'subj_v':'mettiez', 'subj_ils':'mettent',
		'imper_tu':'mets', 'imper_n':'mettons', 'imper_v':'mettez',
		'boot':False}

		self.pleuvoir = {
		'name':'pleuvoir', 'defn':'to rain', 'pc':'avoir plu',
		'pres_je':'-', 'pres_tu':'-', 'pres_il':'pleut',
		'pres_n':'-', 'pres_v':'-','pres_ils':'pleuvent',
		'imp_je':'-', 'imp_tu':'-', 'imp_il':'pleuvait',
		'imp_n':'-', 'imp_v':'-', 'imp_ils':'pleuvaient',
		'fut_je':'-', 'fut_tu':'-', 'fut_il':'pleuvra',
		'fut_n':'-', 'fut_v':'-', 'fut_ils':'pleuvront',
		'cond_je':'-', 'cond_tu':'-','cond_il':'pleuvrait',
		'cond_n':'-', 'cond_v':'-', 'cond_ils':'pleuvraient',
		'subj_je':'-', 'subj_tu':'-', 'subj_il':'pleuve',
		'subj_n':'-', 'subj_v':'-', 'subj_ils':'pleuvent',
		'imper_tu':'-', 'imper_n':'-', 'imper_v':'-',
		'boot':False}

		self.lire = {
		'name':'lire', 'defn':'to read', 'pc':'avoir lu',
		'pres_je':'lis', 'pres_tu':'lis', 'pres_il':'lit',
		'pres_n':'lisons', 'pres_v':'lisez','pres_ils':'lisent',
		'imp_je':'lisais', 'imp_tu':'lisais', 'imp_il':'lisait',
		'imp_n':'lisions', 'imp_v':'lisiez', 'imp_ils':'lisaient',
		'fut_je':'lirai', 'fut_tu':'liras', 'fut_il':'lira',
		'fut_n':'lirons', 'fut_v':'lirez', 'fut_ils':'liront',
		'cond_je':'lirais', 'cond_tu':'lirais','cond_il':'lirait',
		'cond_n':'lirions', 'cond_v':'liriez', 'cond_ils':'liraient',
		'subj_je':'lise', 'subj_tu':'lises', 'subj_il':'lise',
		'subj_n':'lisions', 'subj_v':'lisiez', 'subj_ils':'lisent',
		'imper_tu':'lis', 'imper_n':'lisons', 'imper_v':'lisez',
		'boot':False}

		self.recevoir = {
		'name':'recevoir', 'defn':'to receive', 'pc':'avoir reçu',
		'pres_je':'reçois', 'pres_tu':'reçois', 'pres_il':'reçoit',
		'pres_n':'recevons', 'pres_v':'recevez','pres_ils':'reçoivent',
		'imp_je':'recevais', 'imp_tu':'recevais', 'imp_il':'recevait',
		'imp_n':'recevions', 'imp_v':'receviez', 'imp_ils':'recevaient',
		'fut_je':'recevrai', 'fut_tu':'recevras', 'fut_il':'recevra',
		'fut_n':'recevrons', 'fut_v':'recevrez', 'fut_ils':'recevront',
		'cond_je':'recevrais', 'cond_tu':'recevrais','cond_il':'recevrait',
		'cond_n':'recevrions', 'cond_v':'recevriez', 'cond_ils':'recevraient',
		'subj_je':'reçoive', 'subj_tu':'reçoives', 'subj_il':'reçoive',
		'subj_n':'recevions', 'subj_v':'receviez', 'subj_ils':'reçoivent',
		'imper_tu':'reçois', 'imper_n':'recevons', 'imper_v':'recevez',
		'boot':True}

		self.courir = {
		'name':'courir', 'defn':'to run', 'pc':'avoir couru',
		'pres_je':'cours', 'pres_tu':'cours', 'pres_il':'court',
		'pres_n':'courons', 'pres_v':'courez','pres_ils':'courent',
		'imp_je':'courais', 'imp_tu':'courais', 'imp_il':'courait',
		'imp_n':'courions', 'imp_v':'couriez', 'imp_ils':'couraient',
		'fut_je':'courrai', 'fut_tu':'courras', 'fut_il':'courra',
		'fut_n':'courrons', 'fut_v':'courrez', 'fut_ils':'courront',
		'cond_je':'courrais', 'cond_tu':'courrais','cond_il':'courrait',
		'cond_n':'courrions', 'cond_v':'courriez', 'cond_ils':'courraient',
		'subj_je':'coure', 'subj_tu':'coures', 'subj_il':'coure',
		'subj_n':'courions', 'subj_v':'couriez', 'subj_ils':'courent',
		'imper_tu':'cours', 'imper_n':'courons', 'imper_v':'courez',
		'boot':False}

		self.dire = {
		'name':'dire', 'defn':'to say', 'pc':'avoir dit',
		'pres_je':'dis', 'pres_tu':'dis', 'pres_il':'dit',
		'pres_n':'disons', 'pres_v':'disez','pres_ils':'disent',
		'imp_je':'disais', 'imp_tu':'disais', 'imp_il':'disait',
		'imp_n':'disions', 'imp_v':'disiez', 'imp_ils':'disaient',
		'fut_je':'dirai', 'fut_tu':'diras', 'fut_il':'dira',
		'fut_n':'dirons', 'fut_v':'direz', 'fut_ils':'diront',
		'cond_je':'dirais', 'cond_tu':'dirais','cond_il':'dirait',
		'cond_n':'dirions', 'cond_v':'diriez', 'cond_ils':'diraient',
		'subj_je':'dise', 'subj_tu':'dises', 'subj_il':'dise',
		'subj_n':'disions', 'subj_v':'disiez', 'subj_ils':'disent',
		'imper_tu':'dis', 'imper_n':'disons', 'imper_v':'dites',
		'boot':False}

		self.voir = {
		'name':'voir', 'defn':'to see', 'pc':'avoir vu',
		'pres_je':'vois', 'pres_tu':'vois', 'pres_il':'voit',
		'pres_n':'voyons', 'pres_v':'voyez','pres_ils':'voient',
		'imp_je':'voyais', 'imp_tu':'voyais', 'imp_il':'voyait',
		'imp_n':'voyions', 'imp_v':'voyiez', 'imp_ils':'voyaient',
		'fut_je':'verrai', 'fut_tu':'verras', 'fut_il':'verra',
		'fut_n':'verrons', 'fut_v':'verrez', 'fut_ils':'verront',
		'cond_je':'verrais', 'cond_tu':'verrais','cond_il':'verrait',
		'cond_n':'verrions', 'cond_v':'verriez', 'cond_ils':'verraient',
		'subj_je':'voie', 'subj_tu':'voies', 'subj_il':'voie',
		'subj_n':'voyions', 'subj_v':'voyiez', 'subj_ils':'voient',
		'imper_tu':'vois', 'imper_n':'voyons', 'imper_v':'voyez',
		'boot':True}

		self.envoyer = {
		'name':'envoyer', 'defn':'to send', 'pc':'avoir envoyé',
		'pres_je':'envoie', 'pres_tu':'envoies', 'pres_il':'envoie',
		'pres_n':'envoyons', 'pres_v':'envoyez','pres_ils':'envoient',
		'imp_je':'envoyais', 'imp_tu':'envoyais', 'imp_il':'envoyait',
		'imp_n':'envoyions', 'imp_v':'envoyiez', 'imp_ils':'envoyaient',
		'fut_je':'enverrai', 'fut_tu':'enverras', 'fut_il':'enverra',
		'fut_n':'enverrons', 'fut_v':'enverrez', 'fut_ils':'enverront',
		'cond_je':'enverrais', 'cond_tu':'enverrais','cond_il':'enverrait',
		'cond_n':'enverrions', 'cond_v':'enverriez', 'cond_ils':'enverraient',
		'subj_je':'envoie', 'subj_tu':'envoies', 'subj_il':'envoie',
		'subj_n':'envoyions', 'subj_v':'envoyiez', 'subj_ils':'envoient',
		'imper_tu':'envoie', 'imper_n':'envoyons', 'imper_v':'envoyez',
		'boot':True}

		self.sasseoir = {
		'name':'s\'asseoir', 'defn':'to sit', 'pc':'avoir assis',
		'pres_je':'m\'assieds', 'pres_tu':'t\'assieds', 'pres_il':'s\'assied',
		'pres_n':'nous asseyons', 'pres_v':'vous asseyez','pres_ils':'s\'asseyent',
		'imp_je':'m\'asseyais', 'imp_tu':'t\'asseyais', 'imp_il':'s\'asseyait',
		'imp_n':'nous asseyions', 'imp_v':'vous asseyiez', 'imp_ils':'s\'asseyaient',
		'fut_je':'m\'assiérai', 'fut_tu':'t\'assiéras', 'fut_il':'s\'assiéra',
		'fut_n':'nous assiérons', 'fut_v':'vous assiérez', 'fut_ils':'s\'assiéront',
		'cond_je':'m\'assiérais', 'cond_tu':'t\'assiérais','cond_il':'s\'assiérait',
		'cond_n':'nous assiérions', 'cond_v':'vous assiériez', 'cond_ils':'s\'assiéraient',
		'subj_je':'m\'asseye', 'subj_tu':'t\'asseyes', 'subj_il':'s\'asseye',
		'subj_n':'nous asseyions', 'subj_v':'vous asseyiez', 'subj_ils':'s\'asseyent',
		'imper_tu':'assieds-toi', 'imper_n':'asseyons-nous', 'imper_v':'asseyez-vous',
		'boot':True}

		self.dormir = {
		'name':'dormir', 'defn':'to sleep', 'pc':'avoir dormi',
		'pres_je':'dors', 'pres_tu':'dors', 'pres_il':'dort',
		'pres_n':'dormons', 'pres_v':'dormez','pres_ils':'dorment',
		'imp_je':'dormais', 'imp_tu':'dormais', 'imp_il':'dormait',
		'imp_n':'dormions', 'imp_v':'dormiez', 'imp_ils':'dormaient',
		'fut_je':'dormirai', 'fut_tu':'dormiras', 'fut_il':'dormira',
		'fut_n':'dormirons', 'fut_v':'dormirez', 'fut_ils':'dormiront',
		'cond_je':'dormirais', 'cond_tu':'dormirais','cond_il':'dormirait',
		'cond_n':'dormirions', 'cond_v':'dormiriez', 'cond_ils':'dormiraient',
		'subj_je':'dorme', 'subj_tu':'dormes', 'subj_il':'dorme',
		'subj_n':'dormions', 'subj_v':'dormiez', 'subj_ils':'dorment',
		'imper_tu':'dors', 'imper_n':'dormons', 'imper_v':'dormez',
		'boot':False}

		self.prendre = {
		'name':'prendre', 'defn':'to take', 'pc':'avoir pris',
		'pres_je':'prends', 'pres_tu':'prends', 'pres_il':'prend',
		'pres_n':'prenons', 'pres_v':'prenez','pres_ils':'prennent',
		'imp_je':'prenais', 'imp_tu':'prenais', 'imp_il':'prenait',
		'imp_n':'prenions', 'imp_v':'preniez', 'imp_ils':'prenaient',
		'fut_je':'prendrai', 'fut_tu':'prendras', 'fut_il':'prendra',
		'fut_n':'prendrons', 'fut_v':'prendrez', 'fut_ils':'prendront',
		'cond_je':'prendrais', 'cond_tu':'prendrais','cond_il':'prendrait',
		'cond_n':'prendrions', 'cond_v':'prendriez', 'cond_ils':'prendraient',
		'subj_je':'prenne', 'subj_tu':'prennes', 'subj_il':'prenne',
		'subj_n':'prenions', 'subj_v':'preniez', 'subj_ils':'prennent',
		'imper_tu':'prends', 'imper_n':'prenons', 'imper_v':'prenez',
		'boot':False}

		self.vouloir = {
		'name':'vouloir', 'defn':'to want', 'pc':'avoir voulu',
		'pres_je':'veux', 'pres_tu':'veux', 'pres_il':'veut',
		'pres_n':'voulons', 'pres_v':'voulez','pres_ils':'veulent',
		'imp_je':'voulais', 'imp_tu':'voulais', 'imp_il':'voulait',
		'imp_n':'voulions', 'imp_v':'vouliez', 'imp_ils':'voulaient',
		'fut_je':'voudrai', 'fut_tu':'voudras', 'fut_il':'voudra',
		'fut_n':'voudrons', 'fut_v':'voudrez', 'fut_ils':'voudront',
		'cond_je':'voudrais', 'cond_tu':'voudrais','cond_il':'voudrait',
		'cond_n':'voudrions', 'cond_v':'voudriez', 'cond_ils':'voudraient',
		'subj_je':'veuille', 'subj_tu':'veuilles', 'subj_il':'veuille',
		'subj_n':'voulions', 'subj_v':'vouliez', 'subj_ils':'veuillent',
		'imper_tu':'veux', 'imper_n':'voulons', 'imper_v':'voulez',
		'boot':True}

		self.valoir = {
		'name':'valoir', 'defn':'to be worth', 'pc':'avoir valu',
		'pres_je':'vaux', 'pres_tu':'vaux', 'pres_il':'vaut',
		'pres_n':'valons', 'pres_v':'valez','pres_ils':'valent',
		'imp_je':'valais', 'imp_tu':'valais', 'imp_il':'valait',
		'imp_n':'valions', 'imp_v':'valiez', 'imp_ils':'valaient',
		'fut_je':'vaudrai', 'fut_tu':'vaudras', 'fut_il':'vaudra',
		'fut_n':'vaudrons', 'fut_v':'vaudrez', 'fut_ils':'vaudront',
		'cond_je':'vaudrais', 'cond_tu':'vaudrais','cond_il':'vaudrait',
		'cond_n':'vaudrions', 'cond_v':'vaudriez', 'cond_ils':'vaudraient',
		'subj_je':'vaille', 'subj_tu':'vailles', 'subj_il':'vaille',
		'subj_n':'valions', 'subj_v':'valiez', 'subj_ils':'vaillent',
		'imper_tu':'vaux', 'imper_n':'valons', 'imper_v':'valez',
		'boot':False}

		self.ecrire = {
		'name':'écrire', 'defn':'to write', 'pc':'avoir écrit',
		'pres_je':'écris', 'pres_tu':'écris', 'pres_il':'écrit',
		'pres_n':'écrivons', 'pres_v':'écrivez','pres_ils':'écrivent',
		'imp_je':'écrivais', 'imp_tu':'écrivais', 'imp_il':'écrivait',
		'imp_n' :'écrivions', 'imp_v':'écriviez', 'imp_ils':'écrivaient',
		'fut_je':'écrirai', 'fut_tu':'écriras', 'fut_il':'écrira',
		'fut_n':'écrirons', 'fut_v':'écrirez', 'fut_ils':'écriront',
		'cond_je':'écrirais', 'cond_tu':'écrirais','cond_il':'écrirait',
		'cond_n':'écririons', 'cond_v':'écririez', 'cond_ils':'écriraient',
		'subj_je':'écrive', 'subj_tu':'écrives', 'subj_il':'écrive',
		'subj_n':'écrivions', 'subj_v':'écriviez', 'subj_ils':'écrivent',
		'imper_tu':'écris', 'imper_n':'écrivons', 'imper_v':'écrivez',
		'boot':False}


		self.vbs = [
					self.aller, self.sasseoir, self.avoir, 
					self.battre, self.boire, 
					self.conduire, self.connaitre, self.courir, self.craindre, self.croire, 
					self.devoir, self.dire, self.dormir, 
					self.etre, self.ecrire, self.envoyer, 
					self.faire, self.falloir, 
					self.lire,  
					self.mettre, self.mourir, 
					self.ouvrir, 
					self.plaire, self.pleuvoir,self.pouvoir, self.prendre, 
					self.recevoir, self.rire, 
					self.suivre, self.savoir, self.setaire, 
					self.tenir,  
					self.vivre, self.voir, self.vouloir, self.valoir
					]
		
		self.names = []
		self.defns = []
		for i in self.vbs:
			self.names.append(i['name'])
			self.defns.append(i['defn'])
			
		self.conjs = ['Je/J\'', 'Tu', 'Il/Elle', 'Nous', 'Vous', 'Ils/Elles']

if __name__ == '__main__':
	root = Tk()
	FrenchVerbsGUI(root)
#	root.minsize(975,790)
#	root.resizable(False,False)
	root.minsize(445,335)
	root.mainloop()
	